# TrenchAstra
Install: chrome://extensions → Developer mode → Load unpacked → select this folder. Open a token page and reload it once.
Supported: gmgn.ai, axiom.trade, padre.gg / trade.padre.gg (Terminal), photon-sol.tinyastro.io, *.bullx.io.
Alt+P toggles the panel. See PRIVACY.md.

New in 1.1: sell PnL stays constant on partial sells (position PnL = realized + open), editable quick buy/sell buttons (✎ Edit),
PnL card (PNG) for open and closed trades, faster data capture, and Fast mode (Settings → Pick Price / Pick Market Cap).

v1.4: removed the list quick-buy overlay. Added the 📈 Avg line toggle (Trade tab, next to Open positions): a dotted line on the chart at your average buy with live PnL.

v1.6.1: Settings → About with an optional support address (copy + QR).

v1.7.0: default fee/slippage 0.5%; Settings now has a Save settings button (starting balance changes keep PnL).

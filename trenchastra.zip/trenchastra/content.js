/* TrenchAstra — content script (isolated world). Simulation only. */
(() => {
  'use strict';
  const E = globalThis.PTEngine;
  if (!E || window.top !== window) return;
  const KEY = 'papertrencher', LEGACY = 'gmgnpt', HIDE = 'pt_hidden';
  const SITES = [[/gmgn\.ai$/, 'GMGN'], [/axiom\.trade$/, 'Axiom'], [/padre\.gg$/, 'Terminal'], [/tinyastro\.io$/, 'Photon'], [/bullx\.io$/, 'BullX']];
  const siteName = (SITES.find(s => s[0].test(location.hostname)) || [0, location.hostname])[1];

  let S = E.DEF(), ready = false, dirty = false, lastSaved = '', hidden = false;
  let cur = null, tab = 'trade', dbg = [], ticks = 0, tps = 0, toastT = null, raf = null;
  let $ = {}, shadow = null;
  let cardCtx = null, badSels = new Set(), doSaveBalance = null, doSaveSettings = null, tpMemo = {}, pchg = {}, plost = {}, lineStatus = '', lineOn = false, supply = null, supplyAt = 0, badRatio = 0, editQ = false, posSig = null, histSig = null, curSince = Date.now(), lastTickAt = 0, gap = null, cardMsgT = null;
  const PICK = 'pt_pick', HOST = location.hostname;
  let pickAll = {}, pk = {}, pel = {}, plast = {}, pctr = {}, pok = {}, picking = null;

  /* ---------- formatting ---------- */
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fin = x => x != null && isFinite(x);
  const UNITS = [[1e12, 'T'], [1e9, 'B'], [1e6, 'M'], [1e3, 'K']];
  function money(x, sign) {
    if (!fin(x)) return '—';
    const a = Math.abs(x), s = x < 0 ? '-' : (sign && x > 0 ? '+' : '');
    for (let i = 0; i < UNITS.length; i++) {
      if (a >= UNITS[i][0]) {
        let n = a / UNITS[i][0], u = UNITS[i][1];
        if (+n.toFixed(2) >= 1000 && i > 0) { n = a / UNITS[i - 1][0]; u = UNITS[i - 1][1]; }
        return s + '$' + n.toFixed(2).replace(/\.?0+$/, '') + u;
      }
    }
    return s + '$' + a.toFixed(2);
  }
  const SUBS = '₀₁₂₃₄₅₆₇₈₉';
  function px(p) {
    if (!fin(p) || p <= 0) return '—';
    if (p >= 1) return '$' + p.toFixed(p >= 1000 ? 2 : 4);
    const m = p.toExponential(2).split('e'), z = -Number(m[1]) - 1;
    if (z >= 3) return '$0.0' + String(z).split('').map(d => SUBS[+d]).join('') + m[0].replace('.', '');
    return '$' + p.toFixed(z + 3);
  }
  const pct = (x, sign = true) => (fin(x) ? (sign && x > 0 ? '+' : '') + x.toFixed(2) + '%' : '—');
  const cls = x => (x > 0 ? 'up' : x < 0 ? 'dn' : '');
  const dur = ms => (!fin(ms) ? '—' : ms < 60e3 ? Math.round(ms / 1e3) + 's' : ms < 3600e3 ? Math.round(ms / 6e4) + 'm' : (ms / 3600e3).toFixed(1) + 'h');

  /* ---------- storage ---------- */
  function merge(raw) {
    const d = E.DEF();
    const s = Object.assign(d, raw || {});
    const rs = (raw && raw.set) || {};
    s.set = Object.assign(E.DEF().set, rs);
    if (rs.ver !== 2) { if (rs.fee === 1 && rs.slip === 1) { s.set.fee = 0.5; s.set.slip = 0.5; } s.set.ver = 2; } // one-time: old 1% defaults become 0.5%
    s.ui = Object.assign(E.DEF().ui, (raw && raw.ui) || {});
    if (!Array.isArray(s.closed)) s.closed = [];
    return s;
  }
  function load(cb) {
    chrome.storage.local.get([KEY, LEGACY, HIDE, PICK], r => {
      S = merge(r[KEY] || r[LEGACY]);
      pickAll = r[PICK] || {}; pk = pickAll[HOST] || {};
      hidden = !!r[HIDE];
      if (!r[KEY] && r[LEGACY]) dirty = true; // migrate from the pre-release key
      lastSaved = JSON.stringify(S); ready = true; cb && cb();
    });
  }
  function save() {
    if (!dirty) return;
    dirty = false; lastSaved = JSON.stringify(S);
    try { chrome.storage.local.set({ [KEY]: S }); } catch (e) {}
  }
  setInterval(save, 800);
  window.addEventListener('pagehide', save);
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local' || !ready) return;
      if (ch[HIDE]) { hidden = !!ch[HIDE].newValue; applyHidden(); }
      if (ch[PICK]) { pickAll = ch[PICK].newValue || {}; pk = pickAll[HOST] || {}; pel = {}; plast = {}; }
      if (ch[KEY] && ch[KEY].newValue && JSON.stringify(ch[KEY].newValue) !== lastSaved) {
        const tk = S.tokens, nv = merge(ch[KEY].newValue);
        nv.tokens = Object.assign({}, nv.tokens, tk); S = nv; renderAll();
      }
    });
  } catch (e) {}

  /* ---------- data capture ---------- */
  function ingest(url, data) {
    if (!ready || !cur) return;
    const isWS = /^wss?:/i.test(String(url));
    const urlHas = String(url).toLowerCase().includes(cur.addr.toLowerCase());
    let hits = 0, arrDone = false;
    const now = Date.now();
    const walk = (n, inArr, d) => {
      if (!n || typeof n !== 'object' || d > 8) return;
      if (Array.isArray(n)) { for (const x of n.slice(0, 100)) walk(x, true, d + 1); return; }
      if (E.matchesAddr(n, cur.addr) || (urlHas && !inArr && E.hasPrice(n))) {
        if (!(inArr && arrDone) && E.applyTick(S, cur, n, isWS, now)) { hits++; if (inArr) arrDone = true; }
      }
      for (const k in n) { const v = n[k]; if (v && typeof v === 'object') walk(v, false, d + 1); }
    };
    walk(data, false, 0);
    if (hits) { ticks += hits; noteTick(now); dirty = true; schedule(); }
    if (hits || urlHas) {
      dbg.unshift({ t: new Date().toLocaleTimeString(), url: (isWS ? 'WS ' : '') + String(url).replace(/^https?:\/\/[^/]+/, '').slice(0, 70), hits });
      if (dbg.length > 20) dbg.length = 20;
    }
  }
  function noteTick(now) { if (lastTickAt) { const g = now - lastTickAt; if (g < 10000) gap = gap == null ? g : gap * 0.8 + g * 0.2; } lastTickAt = now; }
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__pt !== 1) return;
    ingest(e.data.url, e.data.data);
  });

  /* ---------- actions ---------- */
  function toast(m, bad, ms) {
    if (!$.toast) return;
    $.toast.textContent = m; $.toast.className = 'toast show ' + (bad ? 'bad' : 'ok');
    clearTimeout(toastT); toastT = setTimeout(() => ($.toast.className = 'toast'), ms || 2000);
  }
  function doBuy(usd) {
    const r = E.buy(S, cur, usd, Date.now());
    if (!r.ok) return toast(r.msg, 1);
    dirty = true; toast('Bought ' + money(+usd) + ' · ' + r.msg.replace('Bought ', '')); renderAll();
  }
  function doSell(key, p) {
    const r = E.sell(S, key, p, Date.now());
    if (!r.ok) return toast(r.msg, 1);
    dirty = true; toast(r.msg + ' · ' + money(r.pnl, true), r.pnl < 0); renderAll();
  }
  function resetAll() {
    if (!confirm('Reset the demo account? Positions, history and stats will be erased.')) return;
    const keep = { set: S.set, ui: S.ui, tokens: S.tokens, start: S.start };
    S = E.DEF(); Object.assign(S, keep); S.balance = S.start; dirty = true; renderAll(); toast('Account reset');
  }
  function exportCSV() {
    const rows = [['time', 'side', 'symbol', 'usd', 'price', 'pnl_usd']].concat(S.history.slice().reverse().map(h =>
      [new Date(h.ts).toISOString(), h.side, h.sym, (h.usd || 0).toFixed(2), h.price, h.pnl == null ? '' : h.pnl.toFixed(2)]));
    const csv = rows.map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'trenchastra-history.csv';
    shadow.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  /* ---------- UI ---------- */
  const CSS = `
:host{all:initial}
*{box-sizing:border-box;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}
.w{position:fixed;z-index:2147483647;display:flex;flex-direction:column;background:#0b0f14;color:#e5e9f0;border:1px solid #1f2a37;border-radius:14px;box-shadow:0 18px 50px rgba(0,0,0,.55);font-size:12px;overflow:hidden;transform-origin:top left;line-height:1.35}
.w.min{width:auto!important;height:auto!important}.w.min .sum,.w.min .tabs,.w.min .bd,.w.min .ft,.w.min .rz{display:none}.w:not(.min) .mini{display:none}
.hd{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;background:linear-gradient(180deg,#121a24,#0e151d);border-bottom:1px solid #1f2a37;cursor:move;user-select:none}
.br{display:flex;align-items:center;gap:7px;min-width:0}.br svg{flex:none}.br b{font-size:13px;font-weight:700;letter-spacing:.2px;white-space:nowrap}
.chip{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:999px;background:#16212e;color:#8fa3b8;border:1px solid #223144;white-space:nowrap}
.sim{background:#10281c;color:#4ade80;border-color:#1b4a31}
.mini{font-weight:700;font-size:11px;white-space:nowrap}
.ctl{display:flex;gap:2px}.ctl button{background:transparent;border:0;color:#8392a5;cursor:pointer;border-radius:6px;padding:3px 6px;font-size:11px;font-weight:700}.ctl button:hover{background:#1a2431;color:#e5e9f0}
.sum{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:9px 10px 8px}
.tile{background:#111823;border:1px solid #1a2431;border-radius:10px;padding:6px 8px;min-width:0}.tile small{display:block;color:#7d8da1;font-size:9.5px;font-weight:600;text-transform:uppercase;letter-spacing:.4px}.tile span{display:block;font-weight:700;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tabs{display:flex;padding:0 6px;border-bottom:1px solid #1a2431}.tabs button{flex:1;background:none;border:0;color:#7d8da1;padding:8px 0;cursor:pointer;font-size:11.5px;font-weight:600}.tabs button:hover{color:#cbd5e1}.tabs button.on{color:#4ade80;box-shadow:inset 0 -2px #4ade80}
.bd{flex:1;min-height:0;overflow:auto;padding:10px;scrollbar-width:thin;scrollbar-color:#223144 transparent}
.up{color:#34d399}.dn{color:#f87171}.mut{color:#7d8da1}
.card{background:#111823;border:1px solid #1a2431;border-radius:12px;padding:10px;margin-bottom:10px}
.r1{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}.sy{font-size:15px;font-weight:800}.sub{color:#7d8da1;font-size:10.5px}
.st{font-size:10px;font-weight:700;padding:2px 7px;border-radius:999px}.live{background:#10281c;color:#4ade80}.old{background:#2c2208;color:#fbbf24}.none{background:#2a1215;color:#f87171}
.live:before{content:"";display:inline-block;width:6px;height:6px;border-radius:50%;background:#4ade80;margin-right:5px;animation:p 1.4s infinite}@keyframes p{50%{opacity:.3}}
.g{display:grid;grid-template-columns:1fr 1fr;gap:7px 12px}.g small{display:block;color:#7d8da1;font-size:10px}.g b{font-size:12.5px}
.sec{display:flex;justify-content:space-between;align-items:center;margin:2px 0 6px;color:#7d8da1;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px}
.row{display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap}
.b{flex:1;min-width:56px;border:0;border-radius:9px;padding:9px 0;font-weight:700;cursor:pointer;font-size:12px;color:#fff;transition:filter .12s,transform .05s}.b:hover{filter:brightness(1.12)}.b:active{transform:scale(.97)}
.buy{background:#15803d}.sel{background:#b91c1c}.ghost{background:#182231;color:#cbd5e1;border:1px solid #223144}.sm{padding:6px 0;font-size:11px;border-radius:7px}
.cu{display:flex;gap:6px;margin-bottom:12px}.cu input,.f input{flex:1;min-width:0;background:#0b0f14;border:1px solid #223144;color:#e5e9f0;border-radius:9px;padding:8px 9px;font-size:12px;outline:none}.cu input:focus,.f input:focus{border-color:#4ade80}
.p{background:#111823;border:1px solid #1a2431;border-radius:12px;padding:9px;margin-bottom:8px}.p .t{display:flex;justify-content:space-between;font-weight:700}.p .t a{color:#e5e9f0;cursor:pointer}.p .t a:hover{color:#4ade80}.p .s{display:flex;justify-content:space-between;color:#7d8da1;margin:3px 0 8px;font-size:10.5px}
.empty{color:#7d8da1;text-align:center;padding:18px 6px;font-size:11.5px}
.h{display:flex;justify-content:space-between;gap:8px;padding:7px 0;border-bottom:1px solid #151e29}.h:last-child{border:0}
.big{display:flex;align-items:center;gap:12px;margin-bottom:10px}.big .n{font-size:30px;font-weight:800;line-height:1}.bar{height:7px;border-radius:99px;background:#f87171;overflow:hidden;flex:1}.bar i{display:block;height:100%;background:#34d399}
.sg{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:10px}.sg .tile b{font-size:12.5px}
.f label{display:block;color:#7d8da1;margin:10px 0 4px;font-size:10.5px;font-weight:600}.f .b{margin-top:8px}
.red{background:#b91c1c!important;color:#fff!important}
.dbg{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10px;color:#7d8da1;word-break:break-all;padding:2px 0}
.ft{padding:6px 10px;border-top:1px solid #1a2431;color:#5d6d80;font-size:9.5px;text-align:center}
.toast{position:absolute;left:12px;right:12px;bottom:34px;padding:8px;border-radius:9px;font-weight:700;text-align:center;opacity:0;pointer-events:none;transition:opacity .18s}.toast.show{opacity:1}.toast.ok{background:#15803d}.toast.bad{background:#b91c1c}
.ed{background:none;border:1px solid #223144;color:#8fa3b8;border-radius:6px;padding:2px 7px;font-size:10px;font-weight:700;cursor:pointer;margin-left:6px;text-transform:none;letter-spacing:0}.ed:hover{color:#e5e9f0;border-color:#4ade80}.tpr{display:flex;align-items:center;flex-wrap:wrap;gap:4px;margin:7px 0 3px;font-size:10.5px;color:#8fa3b8;font-weight:700}.tpr input{width:44px;background:#0e151d;border:1px solid #223144;border-radius:6px;color:#e5e9f0;padding:4px 5px;font-size:11px;outline:none}.tpr input:focus{border-color:#4ade80}.tpr .g{color:#4ade80}.tpr .r{color:#f87171}.ed.on{background:#10281c;border-color:#4ade80;color:#4ade80}
.ei{display:flex;align-items:center;gap:3px;background:#111823;border:1px solid #223144;border-radius:9px;padding:3px 5px}.ei input{width:56px;background:transparent;border:0;color:#e5e9f0;font-size:12px;font-weight:700;outline:none;padding:4px 2px}.ei span{color:#7d8da1;font-size:11px;font-weight:700}.ei button{background:none;border:0;color:#f87171;cursor:pointer;font-size:15px;line-height:1;padding:0 3px}
.qrbox{background:#fff;border-radius:12px;padding:10px;width:196px;margin:0 auto}.qrbox svg{display:block;width:100%;height:auto}.addr{font:600 10.5px ui-monospace,SFMono-Regular,Menlo,monospace;word-break:break-all;color:#9fb0c3;margin:10px 4px}.about{margin-top:14px;padding-top:12px;border-top:1px solid #1b2634}.about .h{font-weight:800;font-size:12px;color:#e5e9f0;margin-bottom:4px}.about p{margin:0 0 8px;font-size:10.5px;line-height:1.55;color:#7d8da1}
.ov{position:fixed;inset:0;z-index:2147483647;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.72);backdrop-filter:blur(3px)}.ov.show{display:flex}
.ovb{background:#0b0f14;border:1px solid #1f2a37;border-radius:14px;padding:12px;width:min(94vw,760px);box-shadow:0 20px 60px rgba(0,0,0,.6)}.ovb canvas{display:block;width:100%;height:auto;border-radius:10px}
#hl{position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #4ade80;background:rgba(74,222,128,.15);border-radius:3px;display:none}
.rz{position:absolute;right:0;bottom:0;width:16px;height:16px;cursor:nwse-resize;z-index:5;background:linear-gradient(135deg,transparent 52%,#2c3b4f 52%,#2c3b4f 62%,transparent 62%,transparent 74%,#2c3b4f 74%,#2c3b4f 84%,transparent 84%)}
`;
  // Optional support address (Solana). Change DONATE_ADDR and regenerate DONATE_QR if you ever need to swap it.
  // Your website, added to the X post text. Example: 'https://yourdomain.com'. Leave '' to post without a link.
  const SITE_URL = '';
  // Shown in the top-right corner of PnL cards. Leave '' to hide. CARD_HANDLE example: '@YourProductHandle'
  const CARD_HANDLE = '';
  const DONATE_ADDR = 'EW5zAeNRfu8u2GViNKu9P6XnLuhYWzGDq51mTcFkB4si';
  const DONATE_QR = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33 33" shape-rendering="crispEdges"><path fill="#000" d="M0 0h7v1h-7zM9 0h6v1h-6zM16 0h2v1h-2zM19 0h1v1h-1zM26 0h7v1h-7zM0 1h1v1h-1zM6 1h1v1h-1zM9 1h9v1h-9zM22 1h1v1h-1zM24 1h1v1h-1zM26 1h1v1h-1zM32 1h1v1h-1zM0 2h1v1h-1zM2 2h3v1h-3zM6 2h1v1h-1zM8 2h2v1h-2zM12 2h2v1h-2zM16 2h3v1h-3zM23 2h2v1h-2zM26 2h1v1h-1zM28 2h3v1h-3zM32 2h1v1h-1zM0 3h1v1h-1zM2 3h3v1h-3zM6 3h1v1h-1zM8 3h3v1h-3zM12 3h1v1h-1zM14 3h3v1h-3zM20 3h3v1h-3zM24 3h1v1h-1zM26 3h1v1h-1zM28 3h3v1h-3zM32 3h1v1h-1zM0 4h1v1h-1zM2 4h3v1h-3zM6 4h1v1h-1zM8 4h1v1h-1zM11 4h3v1h-3zM15 4h1v1h-1zM18 4h1v1h-1zM21 4h1v1h-1zM24 4h1v1h-1zM26 4h1v1h-1zM28 4h3v1h-3zM32 4h1v1h-1zM0 5h1v1h-1zM6 5h1v1h-1zM8 5h1v1h-1zM11 5h1v1h-1zM13 5h1v1h-1zM15 5h3v1h-3zM20 5h1v1h-1zM22 5h1v1h-1zM26 5h1v1h-1zM32 5h1v1h-1zM0 6h7v1h-7zM8 6h1v1h-1zM10 6h1v1h-1zM12 6h1v1h-1zM14 6h1v1h-1zM16 6h1v1h-1zM18 6h1v1h-1zM20 6h1v1h-1zM22 6h1v1h-1zM24 6h1v1h-1zM26 6h7v1h-7zM8 7h2v1h-2zM12 7h1v1h-1zM15 7h1v1h-1zM18 7h1v1h-1zM21 7h2v1h-2zM24 7h1v1h-1zM0 8h1v1h-1zM2 8h5v1h-5zM9 8h3v1h-3zM14 8h3v1h-3zM20 8h4v1h-4zM26 8h5v1h-5zM0 9h1v1h-1zM2 9h1v1h-1zM7 9h2v1h-2zM10 9h1v1h-1zM15 9h2v1h-2zM20 9h6v1h-6zM29 9h4v1h-4zM0 10h1v1h-1zM2 10h1v1h-1zM5 10h3v1h-3zM9 10h1v1h-1zM11 10h1v1h-1zM15 10h2v1h-2zM18 10h1v1h-1zM20 10h2v1h-2zM25 10h1v1h-1zM27 10h3v1h-3zM0 11h1v1h-1zM2 11h3v1h-3zM7 11h2v1h-2zM10 11h3v1h-3zM14 11h2v1h-2zM21 11h2v1h-2zM26 11h1v1h-1zM28 11h1v1h-1zM30 11h2v1h-2zM2 12h1v1h-1zM5 12h6v1h-6zM18 12h2v1h-2zM21 12h1v1h-1zM24 12h2v1h-2zM27 12h1v1h-1zM29 12h1v1h-1zM0 13h4v1h-4zM5 13h1v1h-1zM7 13h2v1h-2zM10 13h1v1h-1zM14 13h4v1h-4zM20 13h4v1h-4zM26 13h1v1h-1zM29 13h3v1h-3zM1 14h1v1h-1zM4 14h3v1h-3zM8 14h2v1h-2zM11 14h3v1h-3zM18 14h2v1h-2zM22 14h1v1h-1zM28 14h4v1h-4zM0 15h2v1h-2zM4 15h2v1h-2zM9 15h2v1h-2zM12 15h1v1h-1zM16 15h1v1h-1zM18 15h4v1h-4zM23 15h2v1h-2zM26 15h2v1h-2zM30 15h2v1h-2zM0 16h1v1h-1zM3 16h1v1h-1zM6 16h3v1h-3zM14 16h1v1h-1zM16 16h2v1h-2zM19 16h2v1h-2zM22 16h1v1h-1zM25 16h1v1h-1zM27 16h1v1h-1zM29 16h1v1h-1zM31 16h1v1h-1zM0 17h5v1h-5zM7 17h1v1h-1zM10 17h4v1h-4zM15 17h5v1h-5zM23 17h1v1h-1zM26 17h1v1h-1zM29 17h4v1h-4zM0 18h1v1h-1zM4 18h3v1h-3zM9 18h2v1h-2zM15 18h1v1h-1zM17 18h1v1h-1zM20 18h1v1h-1zM22 18h1v1h-1zM24 18h1v1h-1zM26 18h1v1h-1zM29 18h3v1h-3zM0 19h1v1h-1zM3 19h1v1h-1zM7 19h1v1h-1zM10 19h1v1h-1zM12 19h1v1h-1zM14 19h2v1h-2zM17 19h2v1h-2zM20 19h1v1h-1zM24 19h3v1h-3zM29 19h2v1h-2zM0 20h2v1h-2zM3 20h5v1h-5zM9 20h2v1h-2zM13 20h2v1h-2zM16 20h1v1h-1zM20 20h4v1h-4zM25 20h1v1h-1zM27 20h3v1h-3zM31 20h1v1h-1zM0 21h4v1h-4zM5 21h1v1h-1zM8 21h2v1h-2zM11 21h1v1h-1zM13 21h1v1h-1zM15 21h1v1h-1zM17 21h2v1h-2zM23 21h1v1h-1zM30 21h1v1h-1zM0 22h1v1h-1zM2 22h1v1h-1zM5 22h4v1h-4zM10 22h1v1h-1zM13 22h5v1h-5zM20 22h2v1h-2zM24 22h2v1h-2zM27 22h1v1h-1zM29 22h3v1h-3zM0 23h1v1h-1zM2 23h1v1h-1zM5 23h1v1h-1zM7 23h4v1h-4zM12 23h1v1h-1zM15 23h1v1h-1zM18 23h1v1h-1zM21 23h2v1h-2zM26 23h1v1h-1zM29 23h2v1h-2zM0 24h1v1h-1zM2 24h7v1h-7zM10 24h2v1h-2zM13 24h1v1h-1zM15 24h1v1h-1zM20 24h3v1h-3zM24 24h5v1h-5zM31 24h2v1h-2zM8 25h1v1h-1zM10 25h2v1h-2zM13 25h1v1h-1zM16 25h1v1h-1zM18 25h4v1h-4zM23 25h2v1h-2zM28 25h1v1h-1zM0 26h7v1h-7zM10 26h1v1h-1zM15 26h2v1h-2zM18 26h1v1h-1zM20 26h2v1h-2zM23 26h2v1h-2zM26 26h1v1h-1zM28 26h1v1h-1zM31 26h1v1h-1zM0 27h1v1h-1zM6 27h1v1h-1zM8 27h5v1h-5zM15 27h2v1h-2zM19 27h1v1h-1zM21 27h2v1h-2zM24 27h1v1h-1zM28 27h5v1h-5zM0 28h1v1h-1zM2 28h3v1h-3zM6 28h1v1h-1zM8 28h1v1h-1zM11 28h1v1h-1zM13 28h3v1h-3zM18 28h2v1h-2zM21 28h1v1h-1zM24 28h5v1h-5zM30 28h2v1h-2zM0 29h1v1h-1zM2 29h3v1h-3zM6 29h1v1h-1zM8 29h2v1h-2zM11 29h1v1h-1zM13 29h5v1h-5zM20 29h1v1h-1zM22 29h4v1h-4zM27 29h3v1h-3zM32 29h1v1h-1zM0 30h1v1h-1zM2 30h3v1h-3zM6 30h1v1h-1zM8 30h3v1h-3zM12 30h2v1h-2zM19 30h1v1h-1zM22 30h5v1h-5zM29 30h2v1h-2zM0 31h1v1h-1zM6 31h1v1h-1zM9 31h1v1h-1zM11 31h4v1h-4zM16 31h1v1h-1zM18 31h4v1h-4zM23 31h1v1h-1zM29 31h2v1h-2zM0 32h7v1h-7zM8 32h5v1h-5zM14 32h1v1h-1zM16 32h2v1h-2zM19 32h1v1h-1zM21 32h2v1h-2zM24 32h1v1h-1zM26 32h2v1h-2zM29 32h3v1h-3z"/></svg>';
  const DONATE_OK = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(DONATE_ADDR);
  const LOGO_URI = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAtkElEQVR42u19eZRdVZX3b59z7r1vqvdqykggYSYDEExanPhCFBVn0K7qbttuW0VQZB7aAf1eld22iiDggB3EARGHKkUBB8Qhia34qYQESNICCZmHmuvNdzhn7++PVxUIBAkQJhdnrbvWW6+G9+7+nb3P3r89XOCFugSEF9fzAASRF4F4LlZhy7VtDwNRVC/U+3jhffGJHd+Z8joWj33z0/PWdvmgXu6SPv3itnyW1qSw51a++plXht9b/e5N35gOAEtkuXmh3csL036KENBDS1ZAjb/8iB0Fla0eMa7+/utTT1u9RJablbTUvrhNn3EQmlpw8Mh13SfIj+R1yQ/H3zl6y5tfaJrwgj28QN0OUlQv+3XrD+P6yKptJiwMZO2t7y7/7MyVtNQukeXmRVf1WToLDh392puPcTfJUfXrk9fKz+Sfqz+7bM/PX3RTn2lTVFQA6MjK1/5wjL2Jj6h+NXq9/EL+qfrTqwCgKKKezyCoFz4C8wmAWGc/wQBpkN5Y22pLWe+Cv6/f+rVeIn4+xwovfACo20H69KbWs37F9cZvKJvRikH3V7fYSjr13tPD276P/m4F+iQ/H0FQ+BtaZFWPsw4OIBExD1Y3J3GQ6n7LW95166w7/z4N6uXi8wyEv50DSro0qN8dMvbft+vW9Oul1HAOogGXHF842tON2m8efGj129Yv6K0Wpah6qZdf1IAD6xM1cbD4uA0tJ2BK2CJ0zls7/qC16dyrDzni+NsXbfxwoZd6uavv+UFdPD80QISwokfj5PmCFesIJ0+8vwLAyfMF/f1A1zwBegUE+avBGXW7aSNf+hFaU6e5kaoDQSdskTcpe1z70aYWjv2ptmnDG/8872MjXdKn+6nbPZe3bp4XgieyAPafPpCiQg+A3keZkf5+QEA8qHtcI3qLKJCzFmDGiKua+8YesEe3HfZSb86cOxb9pfj6fuoefq5BoOdK8EtW9OiVS3stALxt7EetD3jjZ1Zd4+9sLalYsuMuTEYc2wHSardjDKm0GzTGHx6d8pGKTCqBgB6jERNa0DLw+e9SIfhHN1yxLGIgQMIJZuU77Zy2Q0wjKq0eGd38+g0zLxt6LkGg51LwXRuXFdZO0+9PNM6rp7yD61EdobNIkhgSRUAYN69G7EAySJAdRNgg4rY7MTdg4ZVrUSyqvTShr0ujq59zu66Za028hsNYi2MlzBDHEHE4rHOWndo+00RRaU1pdPR1G2aePzQJ3N8mAAJasqK4R/BvHbq+ZWcmeF+s5YIwMLPrjRqiemRDG1NsE7FRAo4jSBwDiXUANwBugFAFUCdFIYBNQvp8LLxyECIEInm0Fpgt/3mj5Px3yVDFCrMhJ2CbwCiNow490mZa2k0cVe/B9t2vu/eISwefCxDUM77jly83IMjKpb12ydov5V5Zu+n8gXz2Hs5krko0zXblmqPIiRCMkGhhMQIxEBhiMYAIiBwUxUQUEVCDyDBE2kn4UkjRAD2092ZaJxCQNfQpLtVjSRKFMBGJY0fMoQ3D6qatG6O4UXEqSB3vZnX84rhdn5s6GdS98AEQoSWy3IBIVi5dapes/VLuNbW+c+XI6Wso03I1fH0o12uOQitM0AwhZgdmhggDPHGJMAAHwJJIc2cSEYC0gOoA5uO+6r+Aehl9XQ/fC/Uy+rsUDrrsLyiHfQiMErZ1gatDXF15qtKol0e279w8HjfqTEF6oWvt+OVRO67ofLZBUM+Y4GmpPfWBa/JvCH98vn/krHt0Jv8F43uHc1y3LkxYAMUQYWHnxDUvFubmWwIIhIUAKBJRIBKIkIgYASkiCiBoEPM7cN8Fr0R3v0Nfl3606ZPAXI56FAGSAFIHoS7guvJMfXRkYOvY2NCYa8SSpLzjXFvhlwt3XjPl2QSBDpjgsUJPZqLetOXatmjK1PdqE3xIe+lDLULYOEwsoKxibUkQEyOEQwiLBieoJxHCMIKLYkg9AuqxIEliEFeFpUSQNMRFomgYQEhQMYhCQByAuqTMRZj7uZ17HcpSVKBeprsu/o4Qv40IuwBYiCQgRACHYA4POuSoxX4m3aKygXKNxupo88hrd8772Aj6ujS6+93zF4BHCf7N5WWdsek4g7Q52/jZgxkJ2FlWWisGkMChEYcSuaTesGGp4aKRhksGYxfvjpwdskkyyKBxAkaZUPK0qlmShjJJ2e6uLpSEzwN4NoBdUKgDcBA0AHii1P/C1i7FohluT8DWFCDj7osXE/jHEBoDJAZJDEIIkkicK3ueHxw0+5hTGUKcM4br0SozWnrt1tkfHZsE8WnFOo90EA4IAI8S/Im7r55WyM08ywSpD6RN64wEEWIXusQmqMeNpBbXKrWoNtSIGzvqcWN7lNidkYuGmDEM4jI0VeF7NfgmhrIJUipCi04gaYtMkgAtDMyroLq6VT00+k627h8I0iJKhkkEIIohSIuS72PhF784yQs9UgB094XfBuRECAZBiEGIIFyD1g1J4mqu0HF4fuasU5JGI1atGZ8r4Z/icfv60qEXjj+REJ9Q+A+cG+CoL0ZPH4BHCf6kzZ+f0T7j0LNF6TONyU2tSgUj5XE7Vi1xuV6KqmG1HMaNUbAdBtwwlDcCpUrQXlUpXYVRdWiqEuk6NDXgqchZjuBJ6GnElPFj8slGAguxgkzQAD465m/8xOFJtf5+OPc2EAsg482jQgogOQcv+dKv9piPCTD0qgtPZZKrAdkJSAylGhDUQVQHUShJNNYyZeapfmfb37lKI1YdOd+Vqr83Yt8w0lmvAT3yZEDo6uvT/d3d7mXDfS+NVDJtdfs/3zb53pOnIvYInuxKwJ6++cYZZkbrh2Kisxqe6RyJh7FjaJMdq5ZVVClrhA0LkhBKx6SUg/Y1EflEkgEoYWILUAyggUQ0DBSIFBwrKGiwMolYhwQGkSX4IPgmAaIAtU9Niw+fvgv40Ef1+otWcIiPimAhCKPNHaf+G6vPPwUnXLN5wnw4CMity/+GkvF7AZkOQRUsMRRFgIQAQgpSXBsfvlV53iGc8qfFA2MxdWZfWR+pfx3U2wWBArB/ABSLal7XOpm96arWQlovM7V092oA/V3r5ElrwCPD9DN33NQ53tbyobLGB6q+TB+pjWAoLEf1ONRxkigXJYQwoubh6aoQKoOkLMIVIjUGhXGIqkJhnAhlGL8MQo2JGxoqhPZDADGlEVqFGFosGBYZnUBg4cNm0l5SrxIDVSD3X8Oo9LTRpup/wtEZUOJEKR/sluP4llOA+QTqbrqo3f1OrTn/X0XkAwB2ABSDUIVQFVrVQeREJPSUN8O0d5ztkkSxIXDCm3j2ZUfu9+4X0BIs1ytpqX1N+IM7FGP6LzN/f9zjnSVP6Ib2U7e7cmtf+i312/59Y2f2/t3poGebH03fgjGMZwG0ZQLTmjNeS0aptE8wCkIQETAgLGACiYCcEUEa4LQQWgRUgOM2iLQqprwIsnA27RD5NrY+nPMQkgFpjcRpP4ZBDFOHmHQu1si1C3BFB1rSiRx/5Qe81pZ36EJhwMtl4c3oXGq20WWgboflRY2ufgYANt4dgB4EiEBIACRQzZQlCTkF4yUcPxiPl252EOWihCRyAqzQe7inJ1iLsMyspKX2/9S+/cm2YM5rA/ZvbIJystp/NnSC5DpldFkBXtsZt/j6Eufz9FJUHq7Xhv/IIjsV2+0syU62PEDWjimtx/1ENRo5vwZIDBtaSbQDJwIPLJoUmIwoUoDyBeRr0R5E0laxhobRRkg7QwAFsEoRQVtJtBdrTxQS37oEZafZDyxSoQasQ9UnlD/lxy1H/iSzed0fdZC6Kl1o+0dbD3vd9o//pDSrdzWkS0P6GES7afWFdwnUYgBJ0wYontiICkpCRSbtOPqVqtExSPvHIQ4Fe/jxv74misKSk0o3vjuV6fhE3Q5aVU9+jRxkat+Q7B8AExUER+z8+pSGC7p12hRia8+uNIbv7dyeDKxdcE71QPnAj+afnRQVNsMHhwFCMvADDVEqyXqUAVB3ELgaoDRnAaAKUC5goIJq5cH2+pwp1XlY+e7y+Mm/yra0fT4dtHy3JJjbTNb0KwCOjSwnixMAJYBAsXisyAKAYlasVKxY0uDGt1BKPiFKYSIa3w9TvdS+bPRrS4JMy/UaJLDJQ7u2Dt8HAT0e2/pYACZs3QZZPraBln55n9qBPgWse4Q6zpc9fHzXvObrnkf8TU+PoKfn4d/vefQ/XU9AF7oAzJuzLu6lz4aP/o36BAvBzEREUtvHxpmx87r0rvSi9Fj7h752zMjVf2xtOejWl1a+ddWf8t0XLJHlZiUAUHwP4A8AnFZAwiBAWIGUsCIBQ4G0wKMBhPY2smqBTNr/x0kGTZ6TCwe/cqSfa/2hI1AAAy3uF6sWn5U0P3vf5ZK0P2o1FUPSj3XyZF2xfYLXUyTMX9/83K55ss8gR7o0VswjnNzrgCItwcnq0fWeSzZd1YoWlWMylK9S9adfP7uEXuz1v47d8um2lrZDruBEvv7/Ot71eywvGizttereC88R5pOg1BCYEihEBNUAUQJFzSCNkUB7kCg8WBZe+fG/mhxCjxz20Gfz02bO+UM6lZ1rk0bS6rV5PF495Sdtp//6r+Ubnjk6WkBAkdA/Iezuft6nGydneqmdbTPabH52tr1tUQYt89J1rNnMu284ZvriaFLwx625ODvjsMWvJ2PeYMicECg9E4KcAMSQuoUMNFx8D0vyy7Hy5p+vmXnZUNMjLKpvf+CguRunn7ke6FOgbof7zn0FOXUJiAYBiiEUgiQkpWIFHTMQg9AAtK99/l1y1GdXPybvMKF1XehX/Vgni+uH3Z7NtL/WRrUkFWS8dMQ7dq0dOGrV4rPq+0wcPaMAPN4H/u+lLX4jmu6Mmi3s5grLCSC92G9pO7Ll8INTmRADqQSXHdYy49u3o2pB3e5ld16Y9o5b9KHAy3ww5WcO0yBoCDwoKChIk9zZczkwGnF1wNr4xuGhgc//Zc5Fux7zvVaf30qQL4AUAagBOoRGmUARhCyIImhYFm8IjUNuxuKzkr9y6Np5pa9en89PeZ9EdQsitPud2lUrX7+j5e1ndInofiL37OWEixP+7gPnBqja46DNbCV8iIiegTCekkAVkKANpNpJUBDlHeJEIR6qXj6sRj+Fzt7yA032k+eOXncScq3XBl5+gZIIDjEIAQCCiyKrSFUtnLBwhoIgADQSxBCFaTpTuKRtpvfPi0rXfnRV4ewbiiKql0iaIFwzjtXnbgO746BUAmFpOkIsAAGaABgDH3di/lnJPqmIu5Z5K2lpctj4f39c5Qvva4TlxJDyfNJOARQn7scTjvyzmJSfDDbuvLCdqu4bgDkSDpFA10DUANAA4EBSBaAEVACwAlp6ylPPXwkpqnnS568nig8f+8r7U9mW/1aeVnFcY89vUXFc2wk3emsUjf+6Ho9sqJrRkVASCZJca3t++qGacy9n45+eTbUdY10ICzeD853fPLp03dG9RB+D9GmsWEdArxWt15Pll0OkAmJAlAKUBpghJsOk7sGRn9q2T+FL0YDOSqYMX/WvKGT+I65XrREyokRa/KyOosrArmRgRVP83fzsADC589dcnCWOb4CoxYDa2uRdEAKUTJwBAqgsSJiMf2XbsR3fGEG9AVmWAdqi9dQdTx259gy05q+LG7FVRquEqFGuDX121+67lw0cceXgPj59+0PAWgC3YdPxlx/XcdY/wSt8FCnv4KRWiyjf+tFDRq9NbaXuiyDLPAAAu/UgNgLKEvSEiWAF0gYsIaz3+31a6eVFA+q1hd2XnyLp4GtRueZYSDttSENZnzK6kZTvWD/tnOr+JPsPTEJmsvpYzvRIku9AaAmAUZCkAPEA8gEhEdaAFITU3aY1dyEf+4ZrR1APUEq1ADtDULcLdn36ZJeir0aVahwGxoyEtbWbx+5/1ZrcP//HwBFXDi6R5aarb6Ls/BFXUUQtkeWma85RlXvzZ39l484//l29Xvp1lA2CsdHBsJozF/pbPnU+6KwEAoKNHgIohKAdwgZgCEEJJMOgu3BC73hTo7F3rnlpr/W2fvxYm9I/cFGioyiiWBxZtshojxwc1ZP6DwFgcMW6Jzxj6YAIv79b4R9+4GjNhd8X67pJsAWKLMAxBA0oVQHDg6IhCcz3MXf6LwDFqI/nkPEcVm0dxqJlFuM9BV311xjjH5zKZJUBrR0Z+93rMOemXYtkmbcKZ9r9cYOXyHKzUi21+P2sdOthF90Yp8074kotZkVau8ZLkoN77wUA3P2hG0nUS6HVXSBsBKlAlDcAv/FlHPnFeC/ff9K8binONL5/p1HebB0ze76ntNZo9TNycMtUSqJ4cHhT+Yj7555R+WvezwHUgH6F7n5Hay+5DsZ0k6hBkPIh8AEFgVIi6ICnV5up+U9i7syfA+UMGuN5KBjA1LFomQWR0M7ow0xudlyrS6VcHRnZveVtmHPTLkjRrKKzkv2NQVbSUovvd2m8Ykdj/Oe3vCusVtZZ53yu1XUy0vjcw/0CtAUk7RAokJCAPLD8tsndFx8WXrHp62PXxVlqxLcyY7Yt113CTkVJAusc8n7aCXyJE/uL++eeUemSPv1Ewn/6Z0BflwZ1O1p/yeXI+O/HcKMMQgBBDFAkkDxAY/DVMpnf9sMEGQSl8c4oMA6x1fDTMfDhMogEay6eijj+V+yO69KazUi1/O+Y+5mHcNeZHqg3edLfrbvfQfo0UXeoNr78PdJQK6XRIGh6HdZcdDKA5VBqkzAXCJKAKQultuPYzN0TBy/vcV371xPQA+zm70pOLcJQybrANyCBcxpt6RwCrSlBQjaR/mcnKS99Gt39ztv4sTPQkrlURhoxgAAggEAApoLoL2jPnYf5M76HkmRQLrUIQaFqAzikUGmM7rGCEp0OdjkBVzFevRPH3H8D+ro0Fl+XPOXvSN1OlheNPfwzf5aw/h0oIQgPg/EOAIDWD5EoDTBAyoD0r5uR+R7ahLCi2EzsrB6/BqC3oNQowzlCGMOFCRQL2tM5Fm10o1Hd5bbu/M3+eD8HwAR1MUSInTlXYghRk7USYQVQAKO/irkzzkrNKWzA7vFpqNsAVntxwwVIOIsq6pjWW0VPkSbo4FcBvI0ULDz/G6B+hynznv4ZNbReIELGyFcJdhcU7yDwCbjzwjQMb4IxFZAmEdmKBZ+9t7n7JyLe5UWNpb0Wd51zKQneQyzbiZAAUiO2oYQN7szl4WvDjgySxP703oWX1vbX/Dx1AKSoQCQzdl55NGnMQyMBiIxAAKVboHRf5vjD/gvjYcoNVNqgYCBJClGSQkIZhDA4pH0HgGaB7R//pQPiOoRoSICtSNxyAMAKPP0a/u5+ByKxx8+7G0RrSFAFQaCjw5B95QClUoNCwhD8vCm0id0vXU3hr/rQP0LROSDaCnAMcB2QBgvXfT+I2vMFOBaVsEUcu+8+W3VBCgAidm+QQtoQ4AQQ0sqD0Ihuz90Qb985w5MkJVHim5jTJpE0GpwGIw9Ru0DnR1i+pHkGBdkZUMaSMoNQci9SW7btAeeAxShnJSC5F6RHQGoEgTeLZv9DgzLebrCsx8Kr1je9ll5unm39Dvd+cAkpdRGR2i6QmhCqIKmBpA52cXtnuxGQWF+psFHbxH+u/B4E9FM3P9MAMAEIid7CVgAQAWBJ+YqM7lMZGhTnchIjBUcZsZQSJ2ltpYAYVRzWsw0CwskrJ6rdvBxIDYP0AEA7saA/PqARes8en3sTCGMgGoNDVkSgEjcIyO+aHlaRIEWF7n6HNectIOtdDOghCKqAVAmoAFIXZ0upXNblWtu82FnrlEHC+NGGN54fLeHlZr9zx08JgImI94itVx5kOT4RtRiAEIxSqMe7Vc7czOVkqojvibMZccjAIgVGBoCP1tza5s0K8IcLUxAhjyiB0juh1KgiNfyMMbSa6kqZASi1G4YdAEgc34nxyqq9yhpXnT2bRF0ApcsgjIOoSkQliJQBKoGo2tLe2WqZ4YR1EtcliZrmZ2X/kDyzJqgHCgIaUXwKZ70MYusgAniGSKvvkUZdIAUduwxY0mCbhtisOMk7oTWY8uHK5BlyxOHz33MEfu4njkbI6N1CsguKyge8m3FSA4idKLWdSI1q7VcAwHr6Jiy9IdxDpaw+v5VM8D5F2oHUKEhVABqH0iVoXREnQ6lCoZ0yqWwjDJ1LGxWH8dptndua7mv3k6uufgo3ul6IIBHkNOam2yNaKapH21Va/VYino7YpZxIVpxOi5NAYtXJ8O/HMZ/a1Ky57JVjw2uPdgGfsQFvjEFRHeAISpUBFWBV2LK/SfD9Wr29DAEJUhloqoLMuIO/GwBw+KcHmomiXsED5wZKm3cppTwoGgSpBkAVKDUOkgqAcfKM1bmWw+I4hgVzYjQSJ30T7qt+Zg9hEQL1u1eOX9vmJF7C1RAQUQABCj+GsBEnLSKcEXE5sEsBqp1FNuHo/7irGYGuIxBktByfbyU5BASB5SrYQZEEIMojkJl7EjoHJDEE5O4vdijoGc3srhCi8vjDGS0BCKIj/01QaBeoUYGqa1CVSFehUAFUDYJhlcnOTxSl4jBmy2yiStXGYeOHk2fjMwvAiibC6+vha2zGa6NGbGG0pjDZZAzdJwmmQJAGowUsKQhPYaZBLHjJr5ti6CGgx2V3f2paReJ3VxsNCylmsPi6OpBUYe0sca5VkfeS/fWj9+PQoqbIzUIH286SdDLHObSokUfmwc3ai14lSh0MUoMgFYKkzoQKFCpEqkFMQ/D8dtH6WK6GYp0TlzbkQvun0ZkX/u9TrSF9cgCc3Ey+J7CncVOiIpYBjeVOkAYkp5jzEEmD0cFsxlEOf9os9waahVIk4Xj1ktCTTD1ueBhEHgBUYraS49kAp5Wzr5m19cqDgF45EHMe5kmfL0n4DnFxBzEOBdRWHPXFqNkR08v4y0XHsFJzodUISNUBqkKrGrSuQasqlK7AM1UIThFhxdYKOydWAeLsd56OR6melCpTt3vtrs9lrbOvRi2CGO1RnDyokGwjJ1OJKSeQjLB0gFWMyPXjFVc1mkIsEtDNqQcvO1jC+Gy7fUxsFLaigXYAsNlD72LmCMKHO46PGStXPwiCYNVZT52vkqIP6uWRjZvfGSa1VxHTVAhNQVz43eT9YMPFU7UyC0jrYSJdI6PqMFQDqAaoKiAxGTUg1i2EoiNQDVkcE0OMHa7UrFY3Txz0/MwCgD4FAHcp/yTOBjMQNb+FIlkDIAvhHNhlmNEO0sxpfAOLP1tqehck6F9PIEhSDy+AY0gU1pmgENmZAICjzo+U8n4CxnHCzm/E5Q92/uWTZ2DxdcmeJMqT2fVriz6oN37Jji+cVI7GPstJbAB9rIi+E4s/vgsEwY5iRpN3HIxXBpkaFDWgqEZK10mpOhEnZLxRcZyCTd6EKInBDDjrJO0JM/2qPvWiXejr0k81aHwSADSTC0TR2xBoQGuFJNkExFUwpoEkBUI7oIyoYBmO+vQQZKKSYDK4ufecY9jFrxPwdpBUkCRA6I4CAKwt+m7hFbdDeb8m4y9kQa6SNV85ZNfVXc0kyhKzRIpPqA3NGUFd/voFvfGJO7+6aCPFP2iInQovc6gg2AGXWtZk+fu0Z3kuESWkUafA1EmjWaWtdQjjVSiTGoCQSBh1Q6QDwg0RZlgLxJYMeTcCoKfDWan9Nz+99tQHfhYA5lQKLZQiCxdtYaE8gzPMMpVFZYTUF7Cgd+u+DiUS9T6AaiCqEKGOMHFwbh4AINwlKBaVtHV8BOnsBnXQVF9ISZLx+06oXPfpeeuQWknNLsslUjRdIrpL+iau5msIVD91O1B/8sraV8/ancfyBtwUyrQIMrkYOns2FvfWASAYvH+OKBgK/IqFaljiyBrVUEpVVKBHNLmMK5XexNVyEU5eJkSjEBICagIyMt4YiYPptwOQZv3SUyRs95t6pm538OC1J9Uz+G1YDxGNDu921fIGGJ2AiQGtxPM+jGM/8+e9WnsmgDDrLj6RY3xMxDEgHQRqE5GpAtyLW1tfv0dTqJex4+pDcj79stBeOCoIbdySKfgqbKxJxfHnS+H//HL9tBt27+trFrYc2zav9YOvZK9wbpT2Xleql11dkS7VK9VwuPRGHF38HwDI7v7otJqvpyICw9cE0Q7GJEjE6PHKHA6TVyBJXgWRmU0RKSVAuukvqYIEXg6C83DcZ7/4dNuYzJMxP8rYt5psFnq8Grl6rQpFeTgISGkx+iIc+5k/79WdAhDQI3hgNJBITidgiIgywqiC4AMyTFDT5e2NmejFdqBH0Lde46ALts7Y+pVXS2JuSGXyr0HcgJ9KL0ylWr8VBG/cNaX++j9oSdZrjocImkNBBzxzNMNbrFOpI2MwJGq4INOqk7h+fyun3rX76AvuQrGoChcg30jrPEKvhukUA6kEw+VWPVSaz3W7iIWPBnMniBRAwxDKgiRFQg0BOoRoHIl7F15yxS17+g+extpPAHpcl8zXfxwbfpO2QFKrWrGcJa0NQC1C+nwcd/kvJysGHuGFEIhYr71wKaBzrNy4YhApZRjOA2ABagfJcQC2A93Ns6JYVA8e8sEd6MLrj77+mxdmU7mPZJDrAGLoID0jgP92H/rtBoACIQEhhkOMCAkcDNIwSqRaq15beXDTZaUTesdx1zIPi8YyJagUMH0ngh0+to0eqcrhSyWhhUxogZADIQZoHJCMgDJE4ppJJmoHaCWMuwTHXf1QkzHtfdoNfE9sgiaKpI4dXPaSRsG/q1IqY3Dr5gRAKIQcoC/Fois+P1l3+ZgqtI0fLphGcgGzFhFOK5EcwFlmFADOAtQhoJ/gJVf37jFB0ufP2T4yd/PBH7wHAJbu/NLsJD/93WJUV0rR/KyXIwMFb6IyjgGEcKijgTi2WxMnt1Wi0vXr296z5jF3yxdPVQ/Ja6WUvBlCxwAsUGoEUCUACUA+RLIAByBKgcGAEiHqxwlXfqHZLnvgOuqfUAOWYIVaCTAC/60pv0C76jutaK2okM6jEl6B4z/3WOEDaGa6ekVH7tWAYcDFUKTBCCGaoLgpPRCT8Fy5q5gB9da7pE/3oyuZnvr+glnl77znd6veecnymedsAfBJ9OFTS1/3zYWhsccHQnNjpTqhiCAy1nDJpqrEqzdt3bB6aEFv9ZHnz8zSRzosTX1V6Pjtjc3l01yK8iiVAJINELUZgu1QtJOAARYqg1ACZBwk44AbRSY7irmfqwCfn2CDD9w4g/3RAAIRFta//ad6gMUPbdkYcUs64OHyjZj7n//aJNe6ee/6mYlqsnvPm2aUfyaLajS7UiRFzCkIAhaXgkgLmmMJCkLqkzjhqj+hr0sXu/qkl4hfVf7+8sRXFJcePGP19I9tWML7NxW3WQ4+JNi2zZ+hk/+Tz+SXlA0Oqkf1RqNc3+Rq4QYX13aCZBgmM4x4tPqEuefJllccKIpkfzSgSRvziYNfOdIatbA0Nmz9qe1BPBb+hI/R/9Yksrr4MbxNf7dqliCahWJ5OjTWKtIFMKzQZIWcEhArCAyIfCg6EcCfsG6e9Hb1AAKq7qp2Zzvatrn2I/7niPFrzlxJS28rSLFVjaUl3zYtmoM59mSczD2PEApNdOlDQBg804Zth/2/XQed/Yv9znX0AHsqurvmCXoA9PTKIxyLA7roCXcSLbUvG7/x3LgQXLMzGqd6pfHbcsOeioMvCtHTQ/uMACc9ofsufTNpuYmYPw3oRAkCMBQTlLAEAGdAEoARCKkEkvtIsyIN1IU+1U/d7tjxr74zKrTcFNXGoF3y5Vg2/d/tBTRQ7cwjRxYQhVLswKFDI5VgJuK9HIG9qvd6NDCTsG4nIdwlqMwQDK2XZlNJj0xUdAiexfVXNeBknMwrAWhPvTGCRxTKPVT3TsPs8xuQsnrC8DuTKklAeQxVu0jJjaxIKVJWgX2nwHDCABgkIQl3CEovBXAH+rtUf3e3w/Kiua/1/d+ZMnxNly5kTksi9yFbn3Fi5045a3jWh+9Oc3Fmo3kPviepFAQGW1lj88cEEjNFHMbKVOGlq3jwvMbjNUtPJA0eQV8XCSug9m4Nm+gCwmSraY/s2cNPAzR6Atsv/7L9ho5tUwvbtrrK8Pi2Ha8YPeoj2x/l6z+evXTYVnwZRe5OCBEl8c+QJHdAm7xiQIjTsBJAwWNiBZEWYdqOhflP7Bk1MNF9MmvkhpkljN8bRY0cC/vUCOvao55ps9/zxS24OeOXxzoQAcIuLTGlIOSLcxlYFQDwxbIPJRoO0CyWxYYgrjumMjiqAG4cCGsYn1N9jDOxn3mSInpofXOILAYxhSY38J7BsU9WA5ZghV4J2IHWwpvKsMrWRk9tCn8/XLCJPjFf+eNOWQiUkPFOBZd3CrsNAso3ywFJAyDFZJgkISXHyH1jC3Ac7n3YJZ2vt3f+2w7vgf84j9v8b/PO8RiQjEupy3fc9+VXebPyH4/bjt6C8obpnoUjQiSxJRKvJh4SJEkWCgYOaQAtImhloABLBQK3QEwGogOQb5AfE9x9XgJlakp7ZZVOD3kpf6BFp0fTRkbSgRlNWV3yo0w5lfWrBz/kGof/aGOjl4h793E4r3w6GtAlfXpezzr51UXzbhp3te+sa3/vbUukaFbSfuyQCe2ZMnD59IpzDzBLCwkgxLVkdPx6sNQUIQWBBkmKWTwQawCdRPpOPv7z/7VXS9CEm0trL/suAvpHlKo1iERQlCeltsKnHp53yO1BabTA1STXHFtAvlhOw0kaTtLCkoZDVkGybCUvxC0QKTQv1wGgVYQ6AWoF6TzlM6BMAJ3ykQ5SyHoeAij4TiEFLw5INQKYmhZVM8aUdYKKIpTEsXheWjTpug5l7djYYP/yQ/7toWbWjfazU34iiJo99o3WIOYFD0x73++eVPAx+ffyjdTo4PBmUWoKYisIPI2wsbs2OHSjUtoHScAsviLxWeBBEIAkK755P+ZfuRXFYvOQFyH09BDeERXI2VXi4mkEqgEUNZvAOQ2l+mRW65cDnapzUmuTUHsQ60uiArCkxbocBFmAc0ok7yy3ANwKoBUseYDbIKoAUB6i8tAqUKkAyvfhpwKkg4BSnk9p46uUFyDQBh4ppMiDjwBptMBHCjGPAon9tbL0XRdFdyxsP21HL+hxx22qx9ELAYAtbe8pNYX/JIOPCfu9hd4TGjJ/SnW2qcD47DviVL4wPd/Z+SbnEoKotBIELDAQ5U+YpDZErguA7OmmJGq+Pu4zYwJ5L5ESEGIocLPjXQ/Dydto6+j1ycDIq1RLvkyBjiBgUrAgsWQoAYmFiGNGc5YlkYWIBYHRbJMhECkQNEgZUcqQIiMQw8IazCTCTqyz2goylEIWLTCJhBJVfiW1kTOzIzzzx6k3nXJz7o1fu6Xj9G29RPzXDun9DcSe2qgW9FD7SHvO81PfNy2ZU93YeAKBNhlPlQd2ry4Pj9yrjJcVEQ8iAQhpsGQAYtH6rTj+yqG9VHfSFK26+JMQdyFIBpqkGRwYCRR7ADwovUIVUjfoXOtOrtenSGxzYEmLcy3KUY7FtQhcDkwtYJcXoADnOgF0QKgdpNrgBymTzSCVTiMbBJz1U5zzUiaTyiGNDEwSW1/UH0nUzSpKfnpr4bT798pJAOhHFz+R7J7ZqYkT4C1ZXjQbFh38La8l+0+olBMW0WRIDe/Y+qdaubybjE5DEJAgKwIF0CwhuRwvufqKvWf/gNDfpTBvnqao8nOAF4AwDkjTmRBKAHEQKZCmkmh9s25t+SVJqsYctiBxObG2BWw7RaRDOZkCTVNANFVpM9Vo0xH4qRbfD4JUKo3AT3FgAhMEWQTwwFHDacgfifUtqPNPftfZvf7hWxU6GSv0yp4V/GSyY8/82MoJVxJEcnjlm1/xcrkPxNUxq0BahGXblg1r4ihsKKUyEARC4kMoB8GYWPcynPjFyiPN4h7vaM3FC4jdzyBwTWhIsGewH7jZICJ5QDZC0x8A3QrmPATToPRU+KagAj9r/CDwg0B7nodAGwTksacNeZk0eUhD4ggk9EfNcotr8K33dLxz3SM32BKs0CdjBT/VYeDP0txQaY6VJOIjS9/6pJ/PfEIaVUdEqtGoJ1s23b+ZBSBFgQgCCBQ8M1VYzsEJV3z5sUxr0yFQqy56r4CvADAMwICEJ4BQgAKEASADQQuR0iLQ0NqD5wEpH9r34WkDXxvnaQOTCXQqk4PnBDqR+zTwYxfaH/+l7b13P1roK7GCcQAmsD97k3MnZ0xQt5tfufECk0tfZcM6G6WoXBlPNj30YFlpowD4Ahh4XgqCjZIPFmBOT/SYiHMCBFp10Q0QeStIRh52KogAKIhoAASlCCIeoHyA0vCNplQgJgjECwLj5zPwjAcduW1G+bekLPU/ePtPf/9wVm9iBtABEvpTSMgcENZJgG43wS9dvWD0m8N+S/abEKva8x3GzrLt23ZsYaWNJq0IIIfO3OFUj7qY6EYsLxrgEVrQ0xzOKvcF/05JtAhAO4BGc7KVGIAUFBEYBiwGIA9AAK0I2hDl0opaMlAxairiOySMb8pb/477p7yn8jAXVjQrAQb18uMN23jhaMA+SL6FI998g5fP9WmtcnDObR7ernePDsP3PAjBIRMoSvieeHa8aJ/T0icpj9WXvI7E3QCWVLNHTRigSIQc0cQsICEfnpdFewYkGqT13Trwv5e23g9KM87btJdmAXgMxf6M7cvnaE2CcOLwt07UhfyPtTHT2YZ2w8gOM96owigNEFi155Su27eMT73gJ/sMBicj5lUXHqGI/06Al4PU8SA6DFBTAApAAAIPJGqAUv6tFKS/bWde+tu9HYX5hP1wG/9mAHgkCK8Yuv5orzDlVs9LHRUnFXv/+E4T2gRGK0f5tHalxu/Gpl940uPWX+4jVsnuKk7lBHNc3c5mwmz2vIFsR8fPKoVzH64JXV40WAE+YJ04LzQAAGDJ8uVm5dKl9qTNy2Z4M2fclvayi0rRkN1SGzWJMEBgkwkUlaOTtk095/d7Rs7s092djJz/ClMrfRr9/XimJ+K+YACYjBz7qdudsnFZATNm3JxNF149Fg3YLeGIUSDnFVp0VKresqX1rNP2m5Oa7OB/ZNXayT3u2TYxLwgAgOYT73qJ+NQHrgnUrEO/G6QLp4/EA8lgXDEggtPKNer1E7a3n70O/X3qyXaiPF/X8+YpSr1EXJSiuv3oC6KfZd769qhe+vpB/kFep59zIuIyqbzJesElIEhXF/5m1vPvOWIiVASol4jfVr3lyiDbftGOeJetwioSicZHG3M3zzhja3OWw/PjWWB/Exrw8JYg6QWkS/r0Lbm3XUyVUvEQ/yCThrE6yKYLOXUuCLJkxd/GM9Cev0/Se8QI4O7KbRcgV7hqKw9IFIelylh81IYZ7xt+vCzTixpwgKiLyQcz97W85WpTr541DQUKUvnWfE7eD4IsmRwp/OJ6Zteiu5odMv9Q+ek7325/w4vC7+3AmouzeyZmvbiePRDeVb79tDfLb2RB5fqLJqPpF6XzLK0zJ0D4l8rPu15d7X/opcPX5EWEXnx2/LPMHwHAqWM/PP3Eoe+8C2g+reJFyTzL1AUATNtw7dTmPLcX13NAXbwo+OdF1PxCv4X/D4arfwNYQ98GAAAAAElFTkSuQmCC';
  const LOGO = '<img src="' + LOGO_URI + '" width="22" height="22" alt="" style="display:block;filter:drop-shadow(0 0 4px rgba(52,211,153,.45))">';
  const logoImg = new Image(); logoImg.src = LOGO_URI;

  function build() {
    if (document.getElementById('trenchastra-root')) return;
    const host = document.createElement('div');
    host.id = 'trenchastra-root';
    shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>${CSS}</style>
<div class="w" id="w">
  <div class="hd" id="hd">
    <div class="br">${LOGO}<b>TrenchAstra</b><span class="chip sim" title="No real funds, wallet or transactions are involved">SIMULATION</span><span class="mini" id="mini"></span></div>
    <div class="ctl"><button id="zm" title="Smaller">A−</button><button id="zp" title="Larger">A+</button><button id="mn" title="Minimize">—</button></div>
  </div>
  <div class="sum" id="sum"></div>
  <div class="tabs"><button data-tab="trade">Trade</button><button data-tab="stats">Stats</button><button data-tab="hist">History</button><button data-tab="set">Settings</button><button data-tab="dbg">Status</button></div>
  <div class="bd" id="bd">
    <div id="v-trade">
      <div class="card" id="hint" style="display:none"><div class="sub" style="margin-bottom:7px;color:#fbbf24">Link live data from the terminal screen for an exact match (one-time, 2 clicks):</div><div class="row" style="margin:0"><button class="b ghost sm" data-act="pickmc">Pick Market Cap</button><button class="b ghost sm" data-act="pickpx">Pick Price</button></div></div>
      <div id="tok"></div>
      <div class="sec"><span>Quick buy</span><span><span id="feeinfo"></span><button class="ed" id="qed" data-act="qedit" title="Edit quick buy / sell amounts">✎ Edit</button></span></div>
      <div class="row" id="bbtn"></div>
      <div class="cu"><input id="cu" type="number" min="0" placeholder="Custom amount ($)"><button class="b buy" id="cub" style="flex:0 0 72px">Buy</button></div>
      <div class="sec"><span>Quick sell (this token)</span><button class="ed" id="qed2" data-act="qedit" title="Edit quick sell amounts">✎ Edit</button></div>
      <div class="row" id="sbtn"></div>
      <div class="sec" style="margin-top:12px"><span>Open positions</span><button class="ed" id="lnt" data-act="lntoggle" title="Dotted line on the chart at your average buy, with live PnL">📈 Avg line: OFF</button></div>
      <div class="mut" id="lns" style="font-size:10px;margin:-4px 0 6px;min-height:12px"></div>
      <div id="pos"></div>
    </div>
    <div id="v-stats" style="display:none"></div><div id="v-hist" style="display:none"></div><div id="v-set" style="display:none"></div><div id="v-dbg" style="display:none"></div>
  </div>
  <div class="ft">Simulated trading only · Not financial advice · Not affiliated with any trading terminal</div>
  <div class="toast" id="toast"></div><div class="rz" id="rz" title="Drag to resize · double-click to reset"></div>
</div>
<div class="ov" id="ov"><div class="ovb"><canvas id="cv"></canvas><div class="row" style="margin:10px 0 0"><button class="b buy" data-act="cardx" title="Copies the card and opens a ready-to-post X draft">Share on X</button><button class="b ghost" data-act="carddl">Download PNG</button><button class="b ghost" data-act="cardcopy">Copy image</button><button class="b ghost" data-act="cardclose">Close</button></div><div class="mut" style="text-align:center;margin-top:6px;font-size:10.5px">Share on X opens a ready post with the card attached. If it is missing, press Ctrl+V (Cmd+V on Mac).</div><div class="mut" id="ovm" style="text-align:center;margin-top:6px;min-height:14px;font-size:10.5px"></div></div></div>
<div class="ov" id="qov"><div class="ovb" style="width:min(92vw,320px);text-align:center"><div style="font-weight:800;font-size:14px;color:#e5e9f0">Support TrenchAstra</div><div class="mut" style="font-size:11px;margin:2px 0 10px">Solana (SOL) · thank you 💚</div><div class="qrbox">${DONATE_QR}</div><div class="addr">${DONATE_ADDR}</div><div class="row" style="margin:0;justify-content:center"><button class="b buy sm" data-act="dcopy">Copy address</button><button class="b ghost sm" data-act="dqrclose">Close</button></div><div class="mut" id="qm" style="font-size:10.5px;min-height:14px;margin-top:6px"></div></div></div>
<div id="hl"></div>`;
    ['w', 'hd', 'mn', 'zm', 'zp', 'rz', 'sum', 'mini', 'tok', 'bbtn', 'sbtn', 'cu', 'cub', 'pos', 'toast', 'feeinfo', 'qed', 'ov', 'cv', 'ovm', 'hl', 'hint', 'qed2', 'lnt', 'lns', 'qov', 'qm'].forEach(id => ($[id] = shadow.getElementById(id)));
    ['trade', 'stats', 'hist', 'set', 'dbg'].forEach(n => ($['v' + n] = shadow.getElementById('v-' + n)));
    document.documentElement.appendChild(host);
    applyHidden(); placePanel(); buildButtons(); wire(); renderAll();
  }

  function wire() {
    shadow.addEventListener('click', e => {
      const el = e.target.closest('[data-act],[data-tab]'); if (!el) return;
      if (el.dataset.tab) { tab = el.dataset.tab; histSig = null; if (tab === 'set') buildSettings(); renderAll(); return; }
      const a = el.dataset.act;
      if (a === 'buy') doBuy(el.dataset.v);
      else if (a === 'sell') doSell(el.dataset.k, +el.dataset.v);
      else if (a === 'go') { const i = el.dataset.k.indexOf(':'); /* navigate only within the current site's own token route */ openToken(el.dataset.k.slice(i + 1)); }
      else if (a === 'ssave') { if (doSaveSettings) doSaveSettings(); }
      else if (a === 'balsave') { if (doSaveBalance) doSaveBalance(); }
      else if (a === 'dcopy') { copyText(DONATE_ADDR).then(() => { toast('Address copied — thank you 💚'); if ($.qm) { $.qm.textContent = 'Copied ✓'; setTimeout(() => ($.qm.textContent = ''), 2000); } }).catch(() => toast('Could not copy — select the address manually', 1)); }
      else if (a === 'dqr') { if (DONATE_OK) $.qov.classList.add('show'); }
      else if (a === 'dqrclose') $.qov.classList.remove('show');
      else if (a === 'lntoggle') { S.set.line = !S.set.line; dirty = true; lineStatus = ''; syncLine(); lineTick(); }
      else if (a === 'qedit') { editQ = !editQ; dirty = true; buildButtons(); }
      else if (a === 'qdel') { const l = el.dataset.l; if (S.set[l].length > 1) { S.set[l].splice(+el.dataset.i, 1); dirty = true; buildButtons(); } else toast('Keep at least one button', 1); }
      else if (a === 'qadd') { const l = el.dataset.l, arr = S.set[l]; if (arr.length < 8) { arr.push(l === 'buys' ? (arr.length ? arr[arr.length - 1] * 2 : 100) : 10); dirty = true; buildButtons(); } }
      else if (a === 'card') openCard(el.dataset.src, el.dataset.src === 'pos' ? el.dataset.k : el.dataset.i);
      else if (a === 'cardclose') closeCard();
      else if (a === 'carddl') cardDownload();
      else if (a === 'cardcopy') cardCopy();
      else if (a === 'cardx') cardShareX();
      else if (a === 'pickpx') startPick('price');
      else if (a === 'pickmc') startPick('mcap');
      else if (a === 'pickre') { pk = {}; pickAll[HOST] = pk; pel = {}; plast = {}; pchg = {}; plost = {}; autoTries = 0; chrome.storage.local.set({ [PICK]: pickAll }); toast('Re-detecting from the screen…'); }
      else if (a === 'pickclr') { pk = { off: 1 }; pickAll[HOST] = pk; pel = {}; plast = {}; chrome.storage.local.set({ [PICK]: pickAll }); toast('Screen link cleared'); }
      else if (a === 'reset') resetAll();
      else if (a === 'csv') exportCSV();
      else if (a === 'clearh') { if (confirm('Clear trade history? (Stats are kept.)')) { S.history = []; dirty = true; renderAll(); } }
    });
    shadow.addEventListener('change', e => {
      const el = e.target;
      if (el.dataset && el.dataset.pf) {
        const p = S.positions[el.dataset.pkey], v = +el.value, f = el.dataset.pf;
        if (p) {
          if (f === 'tp') { p.tp = v > 0 ? v : null; p.tpDone = false; }
          else if (f === 'sl') p.sl = v > 0 ? Math.min(99, v) : null;
          else if (f === 'tps') { p.tpSell = v > 0 ? Math.min(100, v) : 100; el.value = p.tpSell; }
          dirty = true; lineTick();
        }
        return;
      }
      if (!el.dataset || !el.dataset.list) return;
      const l = el.dataset.list, i = +el.dataset.i; let v = +el.value;
      if (!(v > 0)) v = S.set[l][i];
      if (l === 'sells') v = Math.min(100, v);
      S.set[l][i] = v; el.value = v; dirty = true;
    });
    ['keydown', 'keyup', 'keypress'].forEach(ev => shadow.addEventListener(ev, e => { if (e.target && e.target.tagName === 'INPUT') e.stopPropagation(); }));
    $.ov.addEventListener('click', e => { if (e.target === $.ov) closeCard(); });
    $.qov.addEventListener('click', e => { if (e.target === $.qov) $.qov.classList.remove('show'); });
    $.cub.addEventListener('click', () => doBuy($.cu.value));
    $.cu.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') doBuy($.cu.value); });
    $.cu.addEventListener('keyup', e => e.stopPropagation());
    $.mn.addEventListener('click', () => { S.ui.min = !S.ui.min; dirty = true; placePanel(); });
    const zoom = d => { S.ui.z = Math.max(0.7, Math.min(2, +(S.ui.z + d).toFixed(2))); dirty = true; placePanel(); };
    $.zm.addEventListener('click', () => zoom(-0.1)); $.zp.addEventListener('click', () => zoom(0.1));

    let drag = null, rs = null;
    $.hd.addEventListener('mousedown', e => {
      if (e.target.closest('button')) return;
      const r = $.w.getBoundingClientRect(); drag = { dx: e.clientX - r.left, dy: e.clientY - r.top }; e.preventDefault();
    });
    $.rz.addEventListener('mousedown', e => { const r = $.w.getBoundingClientRect(); rs = { l: r.left, t: r.top }; e.preventDefault(); e.stopPropagation(); });
    $.rz.addEventListener('dblclick', () => { S.ui.w = 340; S.ui.h = null; dirty = true; placePanel(); });
    window.addEventListener('mousemove', e => {
      if (drag) { S.ui.x = Math.max(0, Math.min(innerWidth - 80, e.clientX - drag.dx)); S.ui.y = Math.max(0, Math.min(innerHeight - 40, e.clientY - drag.dy)); placePanel(); }
      else if (rs) { const z = S.ui.z || 1; S.ui.w = Math.max(260, Math.min(900, Math.round((e.clientX - rs.l) / z))); S.ui.h = Math.max(240, Math.min(1400, Math.round((e.clientY - rs.t) / z))); placePanel(); }
    });
    window.addEventListener('mouseup', () => { if (drag || rs) { drag = rs = null; dirty = true; } });
    window.addEventListener('resize', placePanel);
    window.addEventListener('keydown', e => {
      if (e.key === 'Escape') { if (picking) { stopPick(); toast('Cancelled'); } else if ($.qov.classList.contains('show')) $.qov.classList.remove('show'); else if ($.ov.classList.contains('show')) closeCard(); }
      if (e.altKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyP') { hidden = !hidden; chrome.storage.local.set({ [HIDE]: hidden }); applyHidden(); }
    }, true);
  }

  // Navigate within the same site, preserving the site's own URL shape by swapping the address segment.
  function openToken(addr) {
    const p = location.pathname, c = E.parseLocation(p, '', location.hostname);
    if (c && p.toLowerCase().includes(c.addr.toLowerCase())) {
      const i = p.toLowerCase().lastIndexOf(c.addr.toLowerCase());
      location.href = p.slice(0, i) + addr + p.slice(i + c.addr.length) + location.search;
    } else toast('Open this token from the site to view it', 1);
  }

  function applyHidden() { const h = document.getElementById('trenchastra-root'); if (h) h.style.display = hidden ? 'none' : ''; }

  function placePanel() {
    if (!$.w) return;
    const z = S.ui.z || 1;
    $.w.classList.toggle('min', !!S.ui.min);
    $.w.style.transform = z === 1 ? '' : `scale(${z})`;
    $.w.style.width = (S.ui.w || 340) + 'px';
    $.w.style.height = S.ui.h ? S.ui.h + 'px' : '';
    $.w.style.maxHeight = Math.max(200, innerHeight / z - 20) + 'px';
    const x = S.ui.x != null ? S.ui.x : innerWidth - (S.ui.w || 340) * z - 16, y = S.ui.y != null ? S.ui.y : 70;
    $.w.style.left = Math.max(0, Math.min(x, innerWidth - 80)) + 'px';
    $.w.style.top = Math.max(0, Math.min(y, innerHeight - 40)) + 'px';
    $.mn.textContent = S.ui.min ? '▢' : '—';
  }

  function buildButtons() {
    if (!editQ) {
      $.bbtn.innerHTML = S.set.buys.map(v => `<button class="b buy" data-act="buy" data-v="${+v}">$${+v}</button>`).join('');
      $.sbtn.innerHTML = S.set.sells.map(v => `<button class="b sel" data-act="sell" data-k="${cur ? esc(cur.key) : ''}" data-v="${+v}">${+v}%</button>`).join('');
    } else {
      const ed = l => S.set[l].map((v, i) => `<div class="ei">${l === 'buys' ? '<span>$</span>' : ''}<input type="number" min="0" step="any" data-list="${l}" data-i="${i}" value="${+v}">${l === 'sells' ? '<span>%</span>' : ''}<button data-act="qdel" data-l="${l}" data-i="${i}" title="Remove">×</button></div>`).join('')
        + (S.set[l].length < 8 ? `<button class="b ghost sm" style="flex:0 0 auto;padding:6px 12px" data-act="qadd" data-l="${l}">+ Add</button>` : '');
      $.bbtn.innerHTML = ed('buys'); $.sbtn.innerHTML = ed('sells');
    }
    syncLine();
    $.feeinfo.textContent = `fee ${S.set.fee}% · slip ${S.set.slip}%`;
    $.qed.textContent = $.qed2.textContent = editQ ? '✓ Done' : '✎ Edit';
  }

  const ver = () => { try { return chrome.runtime.getManifest().version; } catch (e) { return ''; } };
  function copyText(t) {
    return (navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(t) : Promise.reject()).catch(() => { const a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(a); a.select(); const ok = document.execCommand('copy'); a.remove(); if (!ok) throw new Error('copy'); });
  }
  function buildSettings() {
    $.vset.innerHTML = `<div class="f">
<div class="about" style="margin:0 0 12px;padding:0 0 12px;border:0;border-bottom:1px solid #1b2634"><div class="h" style="font-weight:800;font-size:12px;color:#e5e9f0;margin-bottom:4px">Account balance</div>
<div class="mut" style="font-size:10.5px;margin-bottom:6px">Current balance: <b id="bal-cur">${money(S.start)}</b>. Saving a new balance starts a fresh account: every open position, trade and stat is wiped.</div>
<div class="row" style="margin:0"><input id="s-bal" type="number" min="1" step="any" value="${+S.start}"><button class="b buy" id="s-balsave" data-act="balsave" style="flex:none;padding:9px 14px">Save balance</button></div>
<div id="bal-note" class="mut" style="font-size:10.5px;min-height:14px;margin-top:4px"></div></div>
<label>Trading fee per trade (%)</label><input id="s-fee" type="number" step="0.1" value="${+S.set.fee}">
<label>Slippage (%)</label><input id="s-slip" type="number" step="0.1" value="${+S.set.slip}">
<label>Quick-buy amounts ($, comma separated)</label><input id="s-buys" value="${esc(S.set.buys.join(','))}">
<label>Quick-sell percentages (comma separated)</label><input id="s-sells" value="${esc(S.set.sells.join(','))}">
<label>Default TP / SL for new buys (% from your entry, blank = off)</label>
<div class="row" style="margin:0 0 4px"><input id="s-tp" type="number" min="0" step="any" placeholder="TP %" value="${S.set.tp || ''}"><input id="s-sl" type="number" min="0" step="any" placeholder="SL %" value="${S.set.sl || ''}"><input id="s-tps" type="number" min="1" max="100" step="any" title="TP sells this % of the position" value="${S.set.tpSell || 100}"></div>
<div class="mut" style="font-size:10.5px;margin-bottom:6px">Third box = % of the position the TP sells (100 = everything). You can also change TP/SL on each open position.</div>
<div class="row" style="margin:8px 0 2px"><button class="b buy" id="s-save" data-act="ssave" style="flex:1;padding:9px">Save settings</button></div>
<div id="s-note" class="mut" style="font-size:10.5px;min-height:14px;margin-bottom:8px"></div>
<label>Chart line (beta) — dotted line at your entry with live PnL</label>
<div class="row" style="margin:0 0 4px;align-items:center"><input type="checkbox" id="s-line" style="flex:none;width:16px;height:16px;padding:0;accent-color:#4ade80"><span class="mut">Show on the chart</span></div>
<div id="ln-st" class="mut" style="font-size:10.5px"></div>
<label>Fast mode — read the number straight from the terminal screen</label>
<div class="row" style="margin:0 0 4px"><button class="b ghost sm" data-act="pickpx">Pick Price</button><button class="b ghost sm" data-act="pickmc">Pick Market Cap</button><button class="b ghost sm" data-act="pickre">Re-detect</button><button class="b ghost sm" data-act="pickclr">Clear</button></div>
<div id="pk-st" style="font-size:10.5px;font-weight:700"></div>
<div class="mut" style="font-size:10.5px;margin-top:3px">Click a Pick button, then click the live USD price (or market cap) number on the terminal. Saved per site; the panel then updates the instant the terminal does.</div>
<button class="b ghost" data-act="csv">Export history (CSV)</button>
<button class="b red" data-act="reset">Reset demo account</button>
<div class="mut" style="margin-top:12px;font-size:10.5px">Tip: press <b>Alt+P</b> to show or hide this panel. Drag the header to move it, the bottom-right corner to resize.</div>
${DONATE_OK ? `<div class="about"><div class="h">About TrenchAstra <span class="mut" style="font-weight:600">v${esc(ver())}</span></div><p>Free to use — no ads, no fees, no tracking. If it helps your trading and you would like to support its development, you can send a little SOL. Totally optional.</p><div class="row" style="margin:0 0 4px"><button class="b ghost sm" data-act="dcopy">Copy SOL address</button><button class="b ghost sm" data-act="dqr">Show QR</button></div><div class="mut" style="font-size:10px;font-family:ui-monospace,monospace">${DONATE_ADDR.slice(0, 5)}…${DONATE_ADDR.slice(-5)}</div></div>` : ''}</div>`;
    const lc = shadow.getElementById('s-line'); lc.checked = !!S.set.line;
    lc.addEventListener('change', () => { S.set.line = lc.checked; dirty = true; lineStatus = ''; syncLine(); lineTick(); });
    const g = id => shadow.getElementById(id), list = s => s.split(',').map(x => +x.trim()).filter(x => x > 0).slice(0, 8);
    const FIELDS = ['s-fee', 's-slip', 's-buys', 's-sells', 's-tp', 's-sl', 's-tps'];
    const note = (m, bad) => { const n = g('s-note'); if (n) { n.textContent = m; n.style.color = bad ? '#f87171' : (m.startsWith('Unsaved') ? '#fbbf24' : '#4ade80'); } };
    let balArm = false, balT = 0;
    const bn = (m, bad) => { const n = g('bal-note'); if (n) { n.textContent = m; n.style.color = bad ? '#f87171' : '#4ade80'; } };
    const disarm = () => { balArm = false; clearTimeout(balT); const bt = g('s-balsave'); if (bt) { bt.textContent = 'Save balance'; bt.classList.remove('arm'); bt.style.background = ''; } };
    doSaveBalance = () => {
      const v = +g('s-bal').value;
      if (!(v >= 1) || !isFinite(v)) { disarm(); return bn('Enter a balance of at least $1', true); }
      if (!balArm) {
        balArm = true; const bt = g('s-balsave'); bt.textContent = 'Tap again to wipe & save'; bt.style.background = '#f87171';
        bn('This erases all positions, trades and stats.', true); balT = setTimeout(() => { disarm(); bn(''); }, 5000); return;
      }
      disarm();
      const keep = { set: S.set, ui: S.ui, tokens: S.tokens };
      S = E.DEF(); Object.assign(S, keep); S.start = v; S.balance = v;
      posSig = null; histSig = null; tpMemo = {}; dirty = true;
      buildButtons(); renderAll(); lineTick();
      const cur2 = g('bal-cur'); if (cur2) cur2.textContent = money(S.start);
      bn('Account reset with ' + money(v) + ' ✓'); toast('New balance saved — account reset');
    };
    { const bi = g('s-bal'); if (bi) { bi.addEventListener('input', () => { if (balArm) { disarm(); bn(''); } }); bi.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') doSaveBalance(); }); } }
    doSaveSettings = () => {
      S.set.fee = Math.min(50, Math.max(0, +g('s-fee').value || 0));
      S.set.slip = Math.min(50, Math.max(0, +g('s-slip').value || 0));
      const b = list(g('s-buys').value), s = list(g('s-sells').value).map(x => Math.min(100, x));
      if (b.length) S.set.buys = b;
      if (s.length) S.set.sells = s;
      const tp = +g('s-tp').value, sl = +g('s-sl').value, tps = +g('s-tps').value;
      S.set.tp = tp > 0 ? tp : null; S.set.sl = sl > 0 ? Math.min(99, sl) : null; S.set.tpSell = tps > 0 ? Math.min(100, tps) : 100;
      S.set.ver = 2; dirty = true; buildButtons(); renderAll();
      g('s-fee').value = S.set.fee; g('s-slip').value = S.set.slip; g('s-buys').value = S.set.buys.join(','); g('s-sells').value = S.set.sells.join(',');
      note('Saved ✓'); toast('Settings saved'); setTimeout(() => { const n = g('s-note'); if (n && n.textContent === 'Saved ✓') n.textContent = ''; }, 2500);
    };
    FIELDS.forEach(id => {
      const i = g(id); if (!i) return;
      i.addEventListener('input', () => note('Unsaved changes — tap Save settings'));
      i.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') doSaveSettings(); });
    });
    $.vset.querySelectorAll('input').forEach(i => { i.addEventListener('keydown', e => e.stopPropagation()); i.addEventListener('keyup', e => e.stopPropagation()); });
  }

  /* ---------- rendering ---------- */
  function schedule() { if (!raf) raf = requestAnimationFrame(() => { raf = null; renderLive(); }); }

  function renderSummary() {
    const sm = E.summary(S), st = E.stats(S);
    $.sum.innerHTML = `<div class="tile"><small>Equity</small><span>${money(sm.equity)}</span></div>
<div class="tile"><small>Total PnL</small><span class="${cls(sm.total)}">${money(sm.total, true)}</span></div>
<div class="tile"><small>Cash</small><span>${money(S.balance)}</span></div>
<div class="tile"><small>Win rate</small><span class="${st.winRate == null ? '' : st.winRate >= 50 ? 'up' : 'dn'}">${st.winRate == null ? '—' : st.winRate.toFixed(0) + '%'}</span></div>`;
    $.mini.innerHTML = `<span class="${cls(sm.total)}">${money(sm.total, true)}</span>`;
    shadow.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
    ['trade', 'stats', 'hist', 'set', 'dbg'].forEach(n => ($['v' + n].style.display = n === tab ? '' : 'none'));
  }

  function renderTrade() {
    if ($.hint) $.hint.style.display = (cur && !pk.price && !pk.mcap && !pk.off) ? '' : 'none';
    const t = cur && S.tokens[cur.key];
    if (!cur) $.tok.innerHTML = `<div class="card empty">Open a token page on your trading terminal to start trading.<br><span class="sub">The panel reads the live data the page already receives.</span></div>`;
    else if (!t) $.tok.innerHTML = `<div class="card"><div class="r1"><span class="sy">${esc(E.short(cur.addr))}</span><span class="st none">Waiting for data</span></div><div class="sub">Listening for live price updates… If this stays empty for more than a few seconds, reload the page and check the Status tab.</div></div>`;
    else {
      const age = (Date.now() - t.ts) / 1000, pos = S.positions[cur.key];
      const badge = age < 15 ? '<span class="st live">LIVE</span>' : `<span class="st old">${Math.round(age)}s old</span>`;
      let me = '';
      if (pos) { const a = E.posPnl(S, pos); me = `<div style="grid-column:1/3"><small>Your position (total PnL)</small><b class="${cls(a.total)}">${money(a.val)} · ${money(a.total, true)} · ${pct(a.pct)}</b></div>`; }
      $.tok.innerHTML = `<div class="card"><div class="r1"><div><div class="sy">${esc(t.symbol || E.short(cur.addr))}</div><div class="sub">${esc(t.name || E.short(cur.addr))}</div></div>${badge}</div>
<div class="g"><div><small>Price</small><b>${t.price ? px(t.price) : '<span class="mut">n/a</span>'}</b></div><div><small>Market cap</small><b>${money(t.mcap)}</b></div>
<div><small>Volume</small><b>${money(t.vol)}</b></div><div><small>Liquidity</small><b>${money(t.liq)}</b></div>${t.holders ? `<div><small>Holders</small><b>${Math.round(t.holders).toLocaleString()}</b></div>` : ''}${me}</div></div>`;
    }
    if (!editQ) $.sbtn.querySelectorAll('button').forEach(b => (b.dataset.k = cur ? cur.key : ''));
    renderPositions();
  }

  // Updates open positions in place (no re-created buttons), so clicks are never lost while prices tick.
  function renderPositions() {
    const ps = Object.values(S.positions), sig = ps.map(p => p.key).join('|');
    if (sig !== posSig) {
      posSig = sig;
      $.pos.innerHTML = ps.length ? ps.map(p => `<div class="p" data-pk="${esc(p.key)}"><div class="t"><a data-act="go" data-k="${esc(p.key)}" title="Open token">${esc(p.sym)}</a><span data-f="pnl"></span></div>
<div class="s"><span data-f="vc"></span><span data-f="live"></span></div>
<div class="s"><span data-f="bt"></span><span data-f="nw"></span></div>
<div class="s" data-r="1"><span data-f="rl"></span></div>
<div class="tpr"><span class="g">TP</span><input type="number" min="0" step="any" placeholder="off" data-pf="tp" data-pkey="${esc(p.key)}" value="${p.tp || ''}"><span>%</span><span class="r">SL</span><input type="number" min="0" step="any" placeholder="off" data-pf="sl" data-pkey="${esc(p.key)}" value="${p.sl || ''}"><span>%</span><span>TP sells</span><input type="number" min="1" max="100" step="any" data-pf="tps" data-pkey="${esc(p.key)}" value="${p.tpSell || 100}"><span>%</span></div>
<div class="s" style="margin-bottom:5px"><span data-f="tpst"></span></div>
<div class="row" style="margin:0"><button class="b sel sm" data-act="sell" data-k="${esc(p.key)}" data-v="50">Sell 50%</button><button class="b ghost sm" data-act="sell" data-k="${esc(p.key)}" data-v="100">Close</button><button class="b ghost sm" data-act="card" data-src="pos" data-k="${esc(p.key)}">PnL card</button></div></div>`).join('')
        : '<div class="card empty">No open positions yet.<br><span class="sub">Tap a quick-buy amount to open one.</span></div>';
    }
    if (!ps.length) return;
    const els = {}; $.pos.querySelectorAll('.p').forEach(el => (els[el.dataset.pk] = el));
    const now = Date.now();
    for (const p of ps) {
      const el = els[p.key]; if (!el) continue;
      const a = E.posPnl(S, p), t2 = S.tokens[p.key], live = t2 && now - t2.ts < 60000;
      const set = (f, txt, c) => { const n = el.querySelector('[data-f="' + f + '"]'); if (!n) return; if (n.textContent !== txt) n.textContent = txt; if (c != null && n.dataset.c !== c) { n.className = c; n.dataset.c = c; } };
      set('pnl', money(a.total, true) + ' · ' + pct(a.pct), cls(a.total));
      set('vc', 'Value ' + money(a.val) + ' · Cost ' + money(p.cost));
      set('live', live ? 'live' : 'last known');
      const bmc = p.mcU ? p.mcV / p.mcU : null;
      set('bt', bmc ? 'Bought at MC ' + money(bmc) : (p.enQ ? 'Bought at ' + (p.b === 'm' ? 'MC ' + money(p.enV / p.enQ) : px(p.enV / p.enQ)) : ''));
      set('nw', t2 && t2.mcap ? 'Now MC ' + money(t2.mcap) : '');
      set('rl', 'Sold so far ' + money(a.rl, true) + ' · Still open ' + money(a.un, true));
      el.querySelector('[data-r]').style.display = a.rl ? '' : 'none';
      const lv = (m) => { const x = E.levelMc(p, t2, m); return x > 0 ? ' @ MC ' + money(x) : ''; };
      const parts = [];
      if (p.tp > 0) parts.push(p.tpDone ? 'TP done' : 'TP +' + p.tp + '%' + lv(p.tp));
      if (p.sl > 0) parts.push('SL -' + p.sl + '%' + lv(-p.sl));
      set('tpst', parts.length ? parts.join('  ·  ') : '');
    }
  }

  function renderStats() {
    const s = E.stats(S);
    if (!s.n) { $.vstats.innerHTML = '<div class="card empty">No closed trades yet.<br><span class="sub">A trade counts once you fully close a position. Partial sells are added up into one result.</span></div>'; return; }
    const spark = (() => {
      const c = [0].concat(s.curve), W = 300, H = 64, mn = Math.min(...c, 0), mx = Math.max(...c, 0), r = mx - mn || 1;
      const X = i => (i / (c.length - 1 || 1)) * W, Y = v => H - 4 - ((v - mn) / r) * (H - 8);
      const col = c[c.length - 1] >= 0 ? '#34d399' : '#f87171';
      return `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="none"><line x1="0" x2="${W}" y1="${Y(0)}" y2="${Y(0)}" stroke="#223144" stroke-dasharray="3 3"/><polyline fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round" points="${c.map((v, i) => X(i).toFixed(1) + ',' + Y(v).toFixed(1)).join(' ')}"/></svg>`;
    })();
    const T = (l, v, c = '') => `<div class="tile"><small>${l}</small><b class="${c}">${v}</b></div>`;
    $.vstats.innerHTML = `<div class="card"><div class="big"><div class="n ${s.winRate >= 50 ? 'up' : 'dn'}">${s.winRate.toFixed(1)}%</div><div style="flex:1"><div class="sub" style="margin-bottom:5px">Win rate · ${s.wins}W / ${s.losses}L · ${s.n} trades</div><div class="bar"><i style="width:${s.winRate}%"></i></div></div></div>${spark}<div class="sub" style="margin-top:2px">Cumulative realized PnL (per closed trade)</div></div>
<div class="sg">${T('Realized PnL', money(S.realized, true), cls(S.realized))}${T('Profit factor', s.pf == null ? '—' : s.pf === Infinity ? '∞' : s.pf.toFixed(2), s.pf >= 1 ? 'up' : 'dn')}
${T('Avg win', money(s.avgWin, true), 'up')}${T('Avg loss', money(s.avgLoss), 'dn')}
${T('Best trade', money(s.best, true), cls(s.best))}${T('Worst trade', money(s.worst, true), cls(s.worst))}
${T('Expectancy / trade', money(s.expectancy, true), cls(s.expectancy))}${T('Avg hold time', dur(s.avgHold))}
${T('Current streak', (s.streak > 0 ? s.streak + ' wins' : Math.abs(s.streak) + ' losses'), s.streak > 0 ? 'up' : 'dn')}${T('Open positions', Object.keys(S.positions).length)}</div>`;
  }

  function renderHist() {
    const sig = S.history.length + ':' + S.closed.length + ':' + (S.history[0] ? S.history[0].ts : 0);
    if (sig === histSig) return; histSig = sig;
    const n = S.closed.length, cl = S.closed.slice(-30).map((c, j, arr) => ({ c, i: n - arr.length + j })).reverse();
    const closedHtml = cl.length ? '<div class="sec"><span>Closed trades</span></div><div class="card" style="padding:4px 10px">' + cl.map(({ c, i }) => `<div class="h"><span><b>${esc(c.sym)}</b><div class="sub">${new Date(c.ts).toLocaleString()}</div></span><span style="text-align:right"><b class="${cls(c.pnl)}">${money(c.pnl, true)} · ${pct(c.pct)}</b><div><button class="ed" style="margin:2px 0 0" data-act="card" data-src="closed" data-i="${i}">PnL card</button></div></span></div>`).join('') + '</div>' : '';
    $.vhist.innerHTML = closedHtml + (S.history.length ? '<div class="sec"><span>All trades</span></div><div class="card" style="padding:4px 10px">' + S.history.slice(0, 100).map(h => `<div class="h"><span><b class="${h.side === 'BUY' ? 'up' : 'dn'}">${h.side}</b>${h.tag ? ' <b style="color:' + (h.tag === 'TP' ? '#4ade80' : '#f87171') + '">' + h.tag + '</b>' : ''} ${esc(h.sym)}<div class="sub">${new Date(h.ts).toLocaleString()}</div></span><span style="text-align:right">${money(h.usd)}${h.mc ? `<div class="sub">@ MC ${money(h.mc)}</div>` : ''}${h.pnl != null ? `<div class="${cls(h.pnl)}" style="font-weight:700">${money(h.pnl, true)}</div>` : ''}</span></div>`).join('') + '</div><div class="f"><button class="b ghost" data-act="csv">Export CSV</button><button class="b ghost" data-act="clearh">Clear history</button></div>' : '<div class="card empty">No trades yet.</div>');
  }

  function renderStatus() {
    const t = cur && S.tokens[cur.key], age = t ? ((Date.now() - t.ts) / 1000).toFixed(1) + 's ago' : '—';
    $.vdbg.innerHTML = `<div class="card"><div class="g"><div><small>Version</small><b>TrenchAstra v${esc((() => { try { return chrome.runtime.getManifest().version; } catch (e) { return '?'; } })())}</b></div><div><small>Site</small><b>${esc(siteName)}</b></div><div><small>Updates / sec</small><b>${tps}</b></div>
<div><small>Last update</small><b>${age}</b></div><div><small>Price field</small><b>${t && t.pk ? esc(t.pk) : '—'}</b></div>
<div><small>Avg gap between updates</small><b>${gap == null ? '—' : Math.round(gap) + ' ms'}</b></div><div><small>Screen link</small><b>${esc(pickStatus())}</b></div></div>
<div class="sub" style="margin-top:8px;word-break:break-all">Token: ${cur ? esc(cur.key) : 'none detected'}</div></div>
<div class="sec"><span>Recent captures (hits = price updates)</span></div>` +
      (dbg.length ? dbg.map(d => `<div class="dbg"><b class="${d.hits ? 'up' : ''}">[${d.hits}]</b> ${d.t} ${esc(d.url)}</div>`).join('') : '<div class="empty">Nothing captured yet. Reload the page after installing or updating the extension.</div>');
  }

  function renderLive() { if (!$.w) return; renderSummary(); if (tab === 'trade') renderTrade(); }
  function renderAll() {
    if (!$.w) return; renderSummary();
    if (tab === 'trade') renderTrade(); else if (tab === 'stats') renderStats(); else if (tab === 'hist') renderHist(); else if (tab === 'dbg') renderStatus();
  }

  /* ---------- SPA navigation + timers ---------- */
  let lastKey = null;
  function syncUrl() {
    const c = E.parseLocation(location.pathname, location.search, location.hostname), k = c ? c.key : null;
    if (k !== lastKey) { lastKey = k; cur = c; dbg = []; curSince = Date.now(); plast = {}; pel = {}; pctr = {}; pchg = {}; plost = {}; autoTries = 0; supply = null; supplyAt = 0; badRatio = 0; if ($.w) { buildButtons(); renderAll(); } }
  }
  setInterval(() => { syncUrl(); tps = ticks; ticks = 0; renderAll(); const ps = shadow && shadow.getElementById('pk-st'); if (ps) ps.textContent = pickStatus(); try { if (cur && Date.now() - supplyAt > 15000 && Date.now() - curSince > 1500) { supply = findSupply() || supply; supplyAt = Date.now(); } checkLinks(); autoLink(); } catch (e) {} }, 1000);
  window.addEventListener('popstate', syncUrl);

  /* ---------- PnL card ---------- */
  function cardData(src, k) {
    const now = Date.now();
    if (src === 'pos') {
      const p = S.positions[k]; if (!p) return null;
      const a = E.posPnl(S, p), t = S.tokens[k], cu = t ? (p.b === 'p' ? t.price : t.mcap) : null;
      return { sym: p.sym, chain: p.chain, b: p.b, pnl: a.total, pct: a.pct, inv: p.inv || p.cost, entry: p.mcU ? p.mcV / p.mcU : (p.b === 'm' && p.enQ ? p.enV / p.enQ : null), exit: t && t.mcap ? t.mcap : (p.b === 'm' ? cu : null), exitLabel: 'Current', hold: now - p.ts, ts: now, open: true, path: p.path || [], mk: p.mk || [], ts0: p.ts, rl: a.rl, un: a.un };
    }
    const c = S.closed[+k]; if (!c) return null;
    return { sym: c.sym, chain: c.chain, b: c.b, pnl: c.pnl, pct: c.pct, inv: c.inv, entry: c.entryMc, exit: c.exitMc, exitLabel: 'Exit', hold: c.hold, ts: c.ts, open: false, path: c.path || [], mk: c.mk || [], ts0: c.ts0 || (c.ts - c.hold) };
  }
  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function drawCard(d) {
    const W = 1200, H = 675, cv = $.cv, g = cv.getContext('2d'); cv.width = W; cv.height = H;
    const win = d.pnl >= 0, col = win ? '#34d399' : '#f87171', hi = win ? '#a7f3d0' : '#fecaca', glow = win ? '16,185,129' : '239,68,68';
    const F = 'Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    const T = (txt, x, y, size, weight, color, align) => { g.font = weight + ' ' + size + 'px ' + F; g.fillStyle = color; g.textAlign = align || 'left'; g.fillText(txt, x, y); };
    const fit = (txt, x, y, maxW, size, weight, color, align) => { let sz = size; g.font = weight + ' ' + sz + 'px ' + F; while (sz > 14 && g.measureText(txt).width > maxW) { sz -= 2; g.font = weight + ' ' + sz + 'px ' + F; } g.fillStyle = color; g.textAlign = align || 'left'; g.fillText(txt, x, y); return sz; };
    g.textBaseline = 'alphabetic';
    // background + glow behind the chart
    let gr = g.createLinearGradient(0, 0, W, H); gr.addColorStop(0, '#040807'); gr.addColorStop(1, win ? '#06130d' : '#150808'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    const rg = g.createRadialGradient(880, 360, 10, 880, 360, 430); rg.addColorStop(0, 'rgba(' + glow + ',.30)'); rg.addColorStop(1, 'rgba(' + glow + ',0)'); g.fillStyle = rg; g.fillRect(0, 0, W, H);
    // subtle grid on the chart side
    g.strokeStyle = 'rgba(255,255,255,.045)'; g.lineWidth = 1; for (let i = 0; i < 6; i++) { const y = 175 + i * 74; g.beginPath(); g.moveTo(640, y); g.lineTo(1136, y); g.stroke(); }
    // brand
    if (logoImg.complete && logoImg.naturalWidth) g.drawImage(logoImg, 56, 44, 62, 62);
    T('TrenchAstra', 132, 88, 40, 800, '#e6f4ec');
    // top-right: handle / website (only when set)
    let rx = W - 56;
    if (SITE_URL) { const dom = SITE_URL.replace(/^https?:\/\//, '').replace(/\/$/, ''); T(dom, rx, 84, 28, 600, '#d4e6dc', 'right'); const w2 = g.measureText(dom).width; const cx = rx - w2 - 28, cy = 74; g.strokeStyle = '#d4e6dc'; g.lineWidth = 2.5; g.beginPath(); g.arc(cx, cy, 14, 0, 7); g.stroke(); g.beginPath(); g.ellipse(cx, cy, 6, 14, 0, 0, 7); g.stroke(); g.beginPath(); g.moveTo(cx - 14, cy); g.lineTo(cx + 14, cy); g.stroke(); rx = cx - 40; }
    if (CARD_HANDLE) { T(CARD_HANDLE, rx, 84, 28, 600, '#d4e6dc', 'right'); const w3 = g.measureText(CARD_HANDLE).width; T('𝕏', rx - w3 - 12, 84, 30, 700, '#d4e6dc', 'right'); }
    // coin
    const sym = String(d.sym || 'COIN').replace(/^\$/, '').slice(0, 14);
    const ag = g.createLinearGradient(56, 170, 116, 230); ag.addColorStop(0, '#34d399'); ag.addColorStop(1, '#0b3d27'); g.fillStyle = ag; rr(g, 56, 168, 64, 64, 16); g.fill();
    T(sym.slice(0, 2).toUpperCase(), 88, 211, 28, 800, '#031109', 'center');
    fit('$' + sym, 140, 212, 440, 44, 800, '#f2fbf6');
    T(['LONG', (d.chain || '').toUpperCase(), d.open ? 'OPEN' : 'CLOSED'].filter(Boolean).join('  ·  '), 142, 240, 18, 600, '#7d8da1');
    // big glowing PnL
    g.save(); g.shadowColor = 'rgba(' + glow + ',.75)'; g.shadowBlur = 36; fit(money(d.pnl, true), 56, 372, 560, 128, 800, hi); g.restore();
    // stats table
    const fv = v => (v == null || !isFinite(v)) ? '—' : money(v), mult = d.inv > 0 ? (1 + d.pnl / d.inv) : null;
    const rows = [['Return', pct(d.pct) + (mult != null ? '  (' + mult.toFixed(2) + 'x)' : ''), col], ['Invested', money(d.inv), '#e6f4ec'], ['Entry MC', fv(d.entry), '#e6f4ec'], [d.exitLabel === 'Exit' ? 'Exit MC' : 'Current MC', fv(d.exit), '#e6f4ec'], ['Held', dur(d.hold), '#e6f4ec']];
    rows.forEach((r2, i) => { const y = 432 + i * 40; T(r2[0], 56, y, 25, 500, '#8aa093'); fit(r2[1], 600, y, 300, 27, 700, r2[2], 'right'); });
    T('Simulated trade · Not financial advice · Not affiliated with any trading terminal', 56, 648, 15, 500, '#566a5f');
    // chart: real market-cap readings taken while the trade was open
    const X0 = 664, X1 = 1010, Y0 = 190, Y1 = 560;
    let pts = (d.path || []).filter(p => p && p[1] > 0).map(p => [p[0], p[1]]);
    const t0 = d.ts0 || (d.ts - d.hold), t1 = d.open ? d.ts : d.ts;
    if (d.entry > 0 && (!pts.length || pts[0][0] > t0 + 1000)) pts.unshift([t0, d.entry]);
    if (d.exit > 0) pts.push([Math.max(t1, (pts[pts.length - 1] || [0])[0] + 1), d.exit]);
    pts.sort((a2, b2) => a2[0] - b2[0]);
    if (pts.length >= 2) {
      const tmin = pts[0][0], tmax = Math.max(pts[pts.length - 1][0], tmin + 1);
      let vmin = Infinity, vmax = -Infinity; pts.forEach(p => { vmin = Math.min(vmin, p[1]); vmax = Math.max(vmax, p[1]); });
      if (d.entry > 0) { vmin = Math.min(vmin, d.entry); vmax = Math.max(vmax, d.entry); }
      const pad = Math.max((vmax - vmin) * 0.14, vmax * 0.02); vmin -= pad; vmax += pad;
      const X = t => X0 + (t - tmin) / (tmax - tmin) * (X1 - X0 - 20), Y = v => Y1 - (v - vmin) / (vmax - vmin) * (Y1 - Y0);
      // axis labels
      for (let i = 0; i < 5; i++) { const v = vmin + (vmax - vmin) * (i / 4); T(money(Number(v.toPrecision(3))), W - 48, Y(v) + 6, 17, 500, '#6f8479', 'right'); }
      // entry line
      if (d.entry > 0) { const ey = Y(d.entry); g.setLineDash([7, 7]); g.strokeStyle = 'rgba(230,244,236,.35)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(X0, ey); g.lineTo(X1, ey); g.stroke(); g.setLineDash([]); T('Entry ' + money(d.entry), X1, ey - 9, 15, 600, '#9bb0a4', 'right'); }
      // area + line
      const fillG = g.createLinearGradient(0, Y0, 0, Y1); fillG.addColorStop(0, 'rgba(' + glow + ',.34)'); fillG.addColorStop(1, 'rgba(' + glow + ',0)');
      g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(X(p[0]), Y(p[1])) : g.moveTo(X(p[0]), Y(p[1])))); g.lineTo(X(pts[pts.length - 1][0]), Y1); g.lineTo(X(pts[0][0]), Y1); g.closePath(); g.fillStyle = fillG; g.fill();
      g.save(); g.shadowColor = 'rgba(' + glow + ',.9)'; g.shadowBlur = 18; g.strokeStyle = col; g.lineWidth = 4; g.lineJoin = 'round'; g.lineCap = 'round';
      g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(X(p[0]), Y(p[1])) : g.moveTo(X(p[0]), Y(p[1])))); g.stroke(); g.restore();
      // buy / sell markers
      const mk = (d.mk && d.mk.length ? d.mk : [{ t: pts[0][0], k: 'B', v: pts[0][1] }].concat(d.open ? [] : [{ t: pts[pts.length - 1][0], k: 'S', v: pts[pts.length - 1][1] }]));
      mk.forEach(m => { if (!(m.v > 0)) return; const mx = X(Math.min(Math.max(m.t, tmin), tmax)), my = Y(m.v); g.beginPath(); g.arc(mx, my, 16, 0, 7); g.fillStyle = m.k === 'B' ? '#34d399' : '#f87171'; g.fill(); g.lineWidth = 3; g.strokeStyle = '#06100b'; g.stroke(); T(m.k, mx, my + 6, 17, 800, '#03150b', 'center'); });
      // last-value tag
      const lv = pts[pts.length - 1][1], ly = Y(lv), tag = money(lv); g.font = '800 19px ' + F; const tw = g.measureText(tag).width + 22;
      g.fillStyle = col; rr(g, W - 40 - tw, ly - 17, tw, 34, 8); g.fill(); T(tag, W - 40 - tw + 11, ly + 7, 19, 800, '#041109');
    } else { T('Chart appears after a few seconds of live data', 880, 380, 18, 500, '#566a5f', 'center'); }
    T('Paper trade any coin', W - 56, 640, 26, 700, '#d4e6dc', 'right');
  }
  function openCard(src, k) {
    const d = cardData(src, k); if (!d) return toast('Nothing to show', 1);
    try { drawCard(d); } catch (e) { return toast('Could not draw card', 1); }
    cardCtx = d; $.ovm.textContent = ''; $.ov.classList.add('show'); $.ov.dataset.sym = d.sym;
  }
  function closeCard() { if ($.ov) $.ov.classList.remove('show'); }
  function ovMsg(m) { $.ovm.textContent = m; clearTimeout(cardMsgT); cardMsgT = setTimeout(() => ($.ovm.textContent = ''), 2500); }
  function cardDownload() {
    $.cv.toBlob(b => {
      if (!b) return ovMsg('Could not create image');
      const a = document.createElement('a'); a.href = URL.createObjectURL(b);
      a.download = 'trenchastra-' + String($.ov.dataset.sym || 'trade').replace(/[^\w-]+/g, '') + '-pnl.png';
      shadow.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); ovMsg('Saved');
    }, 'image/png');
  }
  // Short, simple post. Edit the lines below to change the wording.
  function shareText(d) {
    const sym = '$' + String(d.sym || 'COIN').replace(/^\$/, '').slice(0, 14), win = d.pnl >= 0;
    const lines = [money(d.pnl, true) + ' (' + pct(d.pct) + ') on ' + sym + (win ? ' 🟢' : ' 🔴'), 'Paper traded on TrenchAstra'];
    if (SITE_URL) lines.push(SITE_URL);
    return lines.join('\n');
  }
  function cardShareX() {
    if (!cardCtx) return;
    const url = 'https://x.com/intent/post?text=' + encodeURIComponent(shareText(cardCtx));
    try { chrome.storage.local.set({ pt_share: { img: $.cv.toDataURL('image/png'), at: Date.now() } }); } catch (e) {} // the helper on x.com attaches it to the draft
    try { // also copy it, as a backup: Ctrl+V in the post attaches it if auto-attach does not work
      const p = new Promise(res => $.cv.toBlob(res, 'image/png'));
      navigator.clipboard.write([new ClipboardItem({ 'image/png': p })]).catch(() => {});
    } catch (e) {}
    window.open(url, '_blank', 'noopener');
    ovMsg('Opening X… the card attaches itself. If not, press Ctrl+V.');
  }
  function cardCopy() {
    $.cv.toBlob(async b => {
      try { await navigator.clipboard.write([new ClipboardItem({ 'image/png': b })]); ovMsg('Image copied'); } catch (e) { ovMsg('Copy blocked by the browser — use Download'); }
    }, 'image/png');
  }

  /* ---------- fast mode: read price / market cap straight from the screen ---------- */
  const SUBD = '₀₁₂₃₄₅₆₇₈₉';
  function elText(n) {
    if (n.nodeType === 3) return n.data;
    if (n.nodeType !== 1) return '';
    if (n.tagName === 'SUB') return Array.from(n.textContent).map(c => (/\d/.test(c) ? SUBD[+c] : c)).join('');
    let s = ''; for (const c of n.childNodes) s += elText(c); return s;
  }
  const cssEsc = x => (typeof CSS !== 'undefined' && CSS.escape ? CSS.escape(x) : String(x).replace(/[^\w-]/g, '\\$&'));
  function selFor(el) {
    const parts = []; let n = el;
    while (n && n.nodeType === 1 && n !== document.documentElement && parts.length < 40) {
      if (n.id && /^[A-Za-z][\w-]*$/.test(n.id) && !/\d{3,}/.test(n.id)) { parts.unshift('#' + cssEsc(n.id)); break; }
      const p = n.parentElement; let seg = n.tagName.toLowerCase();
      if (p) { const sib = Array.from(p.children).filter(c => c.tagName === n.tagName); if (sib.length > 1) seg += ':nth-of-type(' + (sib.indexOf(n) + 1) + ')'; }
      parts.unshift(seg); n = p;
    }
    return parts.join('>');
  }
  function readScreen() {
    if (!ready || !cur || Date.now() - curSince < 1500) return;
    for (const f of ['price', 'mcap']) {
      const sel = pk[f]; if (!sel) continue;
      let el = pel[f];
      if (!el || !el.isConnected) { try { el = pel[f] = document.querySelector(sel); } catch (e) { el = null; } }
      if (!el) {
        pok[f] = false; const nw = Date.now();
        if (!plost[f]) plost[f] = nw;
        else if (nw - plost[f] > 3000) { delete pk[f]; pel[f] = null; plost[f] = 0; pickAll[HOST] = pk; try { chrome.storage.local.set({ [PICK]: pickAll }); } catch (x) {} autoTries = 0; toast((f === 'price' ? 'Price' : 'Market cap') + ' link lost — re-detecting', 1, 3000); }
        continue;
      }
      plost[f] = 0;
      const txt = elText(el);
      if (txt === plast[f]) { // value unchanged: still verified on screen -> keep it "fresh" so stale network data can never override it
        const tk = S.tokens[cur.key], kf = f === 'price' ? tk && tk.pk : tk && tk.mk;
        if (tk && tk[f] > 0 && kf === 'screen') { tk.scrTs = Date.now(); tk.ts = tk.scrTs; pok[f] = true; }
        continue;
      }
      plast[f] = txt;
      const v = E.parseNum(txt);
      if (v > 0) {
        const now = Date.now();
        if (E.applyScreen(S, cur, f, v, now, pctr, !!pk[f === 'price' ? 'mcap' : 'price'] && now - (pchg[f === 'price' ? 'mcap' : 'price'] || 0) < 4000, supply || (S.tokens[cur.key] && S.tokens[cur.key].ssup) || null)) {
          pok[f] = true; pchg[f] = now;
          const tk = S.tokens[cur.key];
          if (tk && tk.pk === 'screen' && tk.mk === 'screen' && tk.price > 0 && tk.mcap > 0 && now - (pchg.price || 0) < 1500 && now - (pchg.mcap || 0) < 1500) tk.ssup = tk.mcap / tk.price; ticks++; noteTick(now); dirty = true; schedule(); }
      }
    }
  }
  // Looks for labelled "Price" / "Market Cap" values on the page and links them automatically.
  let autoTries = 0;
  function autoLink() {
    if (!ready || !cur || pk.off || (pk.price && pk.mcap) || autoTries >= 15 || Date.now() - curSince < 2500) return;
    autoTries++;
    const LAB = { price: /^price(\s*usd)?:?$/i, mcap: /^(market\s*cap|mkt\s*cap|mcap|mc):?$/i };
    const host = document.getElementById('trenchastra-root');
    const vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const leaves = Array.from(document.body.querySelectorAll('div,span,p,td,label,dt')).filter(e => !e.children.length && e.textContent.length < 20 && !(host && host.contains(e)) && !e.closest('table thead,th'));
    for (const f of ['price', 'mcap']) {
      if (pk[f]) continue;
      for (const lab of leaves) {
        if (!LAB[f].test(lab.textContent.trim()) || !vis(lab)) continue;
        const cands = [lab.nextElementSibling, lab.parentElement && lab.parentElement.nextElementSibling, lab.parentElement && lab.parentElement.lastElementChild];
        const val = cands.find(c => c && c !== lab && vis(c) && E.parseNum(elText(c)) > 0);
        if (!val) continue;
        const sel = selFor(val); let ok = false; try { ok = document.querySelector(sel) === val; } catch (x) {}
        if (!ok || badSels.has(sel)) continue;
        pk[f] = sel; pel[f] = val; plast[f] = null; pickAll[HOST] = pk;
        try { chrome.storage.local.set({ [PICK]: pickAll }); } catch (x) {}
        toast((f === 'price' ? 'Price' : 'Market cap') + ' auto-linked: ' + elText(val).trim(), 0, 3000);
        break;
      }
    }
    if (autoTries >= 3) for (const f of ['price', 'mcap']) if (!pk[f]) autoByValue(f);
  }
  // Fallback when no labels are found: the biggest header number that is close to the value we already know.
  function findSupply() {
    const host = document.getElementById('trenchastra-root');
    for (const lab of document.body.querySelectorAll('div,span,p,td,label,dt')) {
      if (lab.children.length || lab.textContent.length > 20 || (host && host.contains(lab))) continue;
      if (!/^(total\s*)?supply:?$/i.test(lab.textContent.trim())) continue;
      for (const c of [lab.nextElementSibling, lab.parentElement && lab.parentElement.nextElementSibling, lab.parentElement && lab.parentElement.lastElementChild]) {
        const v = c && c !== lab ? E.parseNum(elText(c)) : null; if (v > 1000) return v;
      }
    }
    return null;
  }
  function autoByValue(f) {
    const t = S.tokens[cur.key]; let known = t && t[f], lo = 0.6, hi = 1.6;
    if (supply && t) { // the other field is exact on screen -> the expected value is tight (rejects chart axis labels etc.)
      if (f === 'mcap' && pk.price && t.pk === 'screen' && t.price) { known = t.price * supply; lo = 0.93; hi = 1.07; }
      else if (f === 'price' && pk.mcap && t.mk === 'screen' && t.mcap) { known = t.mcap / supply; lo = 0.93; hi = 1.07; }
    }
    if (!known) return;
    const host = document.getElementById('trenchastra-root');
    const cand = [];
    for (const e of document.body.querySelectorAll('div,span,p,b,strong,h1,h2,h3,a')) {
      if (e.textContent.length > 24 || (host && host.contains(e))) continue;
      const v = E.parseNum(elText(e)); if (!(v > 0) || v / known < lo || v / known > hi) continue;
      const r = e.getBoundingClientRect(); if (!(r.width > 0 && r.height > 0) || r.top > 110) continue;
      cand.push({ el: e, fs: parseFloat(getComputedStyle(e).fontSize) || 0 });
    }
    // keep the innermost element of each nested group, then take the biggest text
    const inner = cand.filter(x => !cand.some(y => y !== x && x.el.contains(y.el)));
    inner.sort((p, q) => q.fs - p.fs);
    let best = null, sel = '';
    for (const x of inner) { const s2 = selFor(x.el); let ok2 = false; try { ok2 = document.querySelector(s2) === x.el; } catch (y) {} if (ok2 && !badSels.has(s2)) { best = x; sel = s2; break; } }
    if (!best) return;
    pk[f] = sel; pel[f] = best.el; plast[f] = null; pickAll[HOST] = pk;
    try { chrome.storage.local.set({ [PICK]: pickAll }); } catch (x) {}
    toast((f === 'price' ? 'Price' : 'Market cap') + ' auto-linked: ' + elText(best.el).trim(), 0, 3000);
  }
  function checkLinks() {
    const t = cur && S.tokens[cur.key]; if (!t) return;
    if (!(supply && pk.price && pk.mcap && t.price > 0 && t.mcap > 0 && t.pk === 'screen' && t.mk === 'screen')) { badRatio = 0; return; }
    const q = t.mcap / (t.price * supply);
    if (q < 0.85 || q > 1.18) {
      if (++badRatio >= 3) { badSels.add(pk.mcap); delete pk.mcap; pel.mcap = null; t.mk = null; pickAll[HOST] = pk; try { chrome.storage.local.set({ [PICK]: pickAll }); } catch (x) {} autoTries = 0; badRatio = 0; toast('Market cap link looked wrong — re-detecting', 1, 3000); }
    } else badRatio = 0;
  }
  function pickStatus() {
    const one = f => (!pk[f] ? 'not set' : pok[f] ? 'live ✓' : 'waiting…');
    return 'Price: ' + one('price') + ' · Market cap: ' + one('mcap');
  }
  let mo = null;
  function startObserver() {
    if (mo || !document.documentElement) return;
    mo = new MutationObserver(() => { if (pk.price || pk.mcap) readScreen(); });
    mo.observe(document.documentElement, { subtree: true, childList: true, characterData: true });
    setInterval(() => { if (pk.price || pk.mcap) readScreen(); }, 200);
  }
  const inOurs = e => { const h = document.getElementById('trenchastra-root'); return !!h && e.composedPath().includes(h); };
  const swallow = e => { if (!picking || inOurs(e)) return; e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };
  function candidate(e) {
    let el = e.composedPath()[0]; if (el && el.nodeType !== 1) el = el.parentElement;
    for (let i = 0; el && i < 4; i++, el = el.parentElement) if (E.parseNum(elText(el)) > 0) return el;
    return null;
  }
  function onPM(e) {
    if (!picking || inOurs(e)) return;
    const el = candidate(e); if (!el) { $.hl.style.display = 'none'; return; }
    const r = el.getBoundingClientRect();
    Object.assign($.hl.style, { display: 'block', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
  }
  function onPC(e) {
    if (!picking || inOurs(e)) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    const el = candidate(e); if (!el) return toast('Click directly on the number', 1);
    const sel = selFor(el); let ok = false; try { ok = document.querySelector(sel) === el; } catch (x) {}
    if (!ok) return toast('Could not lock on to that element — try another spot', 1);
    const f = picking; delete pk.off; pk[f] = sel; pickAll[HOST] = pk; pel[f] = el; plast[f] = null; pctr[f] = 0;
    try { chrome.storage.local.set({ [PICK]: pickAll }); } catch (x) {}
    stopPick(); toast((f === 'price' ? 'Price' : 'Market cap') + ' linked: ' + elText(el).trim()); readScreen();
  }
  const PICK_EVS = ['mousemove', 'click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup'];
  function startPick(f) {
    picking = f; closeCard();
    PICK_EVS.forEach(ev => document.addEventListener(ev, ev === 'mousemove' ? onPM : ev === 'click' ? onPC : swallow, true));
    toast('Click the live ' + (f === 'price' ? 'USD price' : 'market cap') + ' number on the terminal (Esc cancels)', 0, 8000);
  }
  function stopPick() {
    picking = null;
    PICK_EVS.forEach(ev => document.removeEventListener(ev, ev === 'mousemove' ? onPM : ev === 'click' ? onPC : swallow, true));
    if ($.hl) $.hl.style.display = 'none';
  }

  /* ---------- optional chart line ---------- */
  window.addEventListener('message', e => { if (e.source === window && e.data && e.data.__ptl === 2) lineStatus = String(e.data.status || ''); });
  function syncLine() {
    if ($.lnt) { $.lnt.textContent = '📈 Avg line: ' + (S.set.line ? 'ON' : 'OFF'); $.lnt.classList.toggle('on', !!S.set.line); }
    const lc = shadow && shadow.getElementById('s-line'); if (lc) lc.checked = !!S.set.line;
  }
  function lineTick() {
    const p = cur && S.positions[cur.key], t = cur && S.tokens[cur.key];
    if (!S.set.line || !p || !t || !(t.mcap > 0 || t.price > 0)) {
      if (lineOn) { lineOn = false; try { window.postMessage({ __ptl: 1, cur: {}, lines: [] }, '*'); } catch (x) {} }
      return;
    }
    const a = E.posPnl(S, p), rt = t.price > 0 && t.mcap > 0 ? t.price / t.mcap : null;
    const emc = p.mcU ? p.mcV / p.mcU : (p.b === 'm' && p.enQ ? p.enV / p.enQ : null);
    const epx = p.b === 'p' && p.enQ ? p.enV / p.enQ : (emc && rt ? emc * rt : null);
    const mc = emc || (epx && rt ? epx / rt : null);
    lineOn = true;
    const extra = [];
    if (p.tp > 0 && !p.tpDone) { const m1 = E.levelMc(p, t, p.tp); if (m1 > 0) extra.push({ id: 'tp', mc: m1, px: null, text: 'TP +' + p.tp + '%', color: '#22c55e' }); }
    if (p.sl > 0) { const m2 = E.levelMc(p, t, -p.sl); if (m2 > 0) extra.push({ id: 'sl', mc: m2, px: null, text: 'SL -' + p.sl + '%', color: '#ef4444' }); }
    try { window.postMessage({ __ptl: 1, cur: { mc: t.mcap, px: t.price }, lines: [{ id: 'entry', mc, px: epx, text: 'AVG ' + money(mc || 0) + '  ' + money(a.total, true) + ' (' + pct(a.pct) + ')', color: a.total >= 0 ? '#22c55e' : '#ef4444' }].concat(extra) }, '*'); } catch (x) {}
  }
  setInterval(() => { try { if (ready) lineTick(); } catch (x) {} const msg = !S.set.line ? '' : (!(cur && S.positions[cur.key]) ? 'Line is on — open a position on this token to see it' : (lineStatus || 'Looking for the chart…')); const ls = shadow && shadow.getElementById('ln-st'); if (ls) ls.textContent = S.set.line ? msg : 'Off'; if ($.lns) $.lns.textContent = msg; syncLine(); }, 500);

  /* ---------- market-cap history for PnL card charts ---------- */
  setInterval(() => {
    if (!ready) return;
    const now = Date.now();
    for (const p of Object.values(S.positions)) {
      const t = S.tokens[p.key]; if (!t || !(t.mcap > 0) || !t.ts || now - t.ts > 10000) continue;
      const path = p.path || (p.path = []), last = path[path.length - 1];
      if (!last || now - last[0] >= 4000 || (now - last[0] >= 1000 && Math.abs(t.mcap / last[1] - 1) > 0.01)) {
        path.push([now, Math.round(t.mcap)]); dirty = true;
        if (path.length > 240) { const keep = path.filter((_, i) => i === 0 || i === path.length - 1 || i % 2 === 0); path.length = 0; keep.forEach(x => path.push(x)); }
      }
    }
  }, 1000);

  /* ---------- auto TP / SL ---------- */
  setInterval(() => {
    if (!ready) return;
    try {
      const res = E.tpslCheck(S, Date.now(), tpMemo);
      if (res.length) {
        dirty = true; renderAll();
        const x = res[0];
        toast((x.kind === 'TP' ? '🎯 TP hit ' : '🛑 SL hit ') + x.sym + ' · sold ' + x.pc + '% · ' + money(x.pnl, true) + (res.length > 1 ? '  (+' + (res.length - 1) + ' more)' : ''), x.kind === 'SL', 4000);
      }
    } catch (x) {}
  }, 250);

  /* ---------- boot ---------- */
  cur = E.parseLocation(location.pathname, location.search, location.hostname); lastKey = cur ? cur.key : null;
  load(() => {
    startObserver();
    const init = () => build();
    if (document.body) init(); else document.addEventListener('DOMContentLoaded', init, { once: true });
  });
})();

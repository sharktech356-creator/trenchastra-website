/* TrenchAstra — optional chart overlay (page side, OFF unless enabled in Settings).
 * Looks for the page's TradingView chart object and draws one dotted line at your entry with live PnL.
 * It only draws on the chart; it never reads wallets, never sends data anywhere, and does nothing if the chart is not reachable. */
(() => {
  if (window.__ptlHooked) return;
  window.__ptlHooked = true;
  let widget = null, lines = {}, lastStatus = '', lastCmdAt = 0, findAt = 0, busy = false;
  const say = s => { if (s !== lastStatus) { lastStatus = s; try { window.postMessage({ __ptl: 2, status: s }, '*'); } catch (e) {} } };
  const isW = v => { try { return !!v && (typeof v === 'object' || typeof v === 'function') && typeof v.activeChart === 'function'; } catch (e) { return false; } };
  const KEYS = ['tvWidget', 'widget', 'tradingViewApi', 'TradingViewApi', 'tradingViewWidget', 'tvChart', 'chartWidget', 'tv', 'chart'];
  let captured = null, how = '', frames = { total: 0, open: 0 };

  // Catch the chart the moment the page creates it: wrap TradingView.widget (works even when the page keeps it private).
  function wrapTV(tv) {
    try {
      if (!tv || tv.__ptw) return;
      Object.defineProperty(tv, '__ptw', { value: 1 });
      let real = tv.widget;
      const wrap = W => (typeof W !== 'function' ? W : new Proxy(W, { construct(t, a, nt) { const o = Reflect.construct(t, a, nt); if (isW(o)) { captured = o; how = 'TradingView.widget'; } return o; } }));
      Object.defineProperty(tv, 'widget', { configurable: true, enumerable: true, get() { return real; }, set(v) { real = wrap(v); } });
      if (real) real = wrap(real);
    } catch (e) {}
  }
  try {
    let tvReal = window.TradingView;
    Object.defineProperty(window, 'TradingView', { configurable: true, get() { return tvReal; }, set(v) { tvReal = v; wrapTV(v); } });
    if (tvReal) wrapTV(tvReal);
  } catch (e) {}


  function scan(win) {
    for (const k of KEYS) { try { const v = win[k]; if (isW(v)) return v; } catch (e) {} }
    let names; try { names = Object.getOwnPropertyNames(win); } catch (e) { return null; }
    const plain = [];
    for (const k of names) {
      try {
        const d = Object.getOwnPropertyDescriptor(win, k);
        if (!d || !('value' in d)) continue;
        if (isW(d.value)) return d.value;
        const v = d.value;
        if (v && typeof v === 'object' && Object.getPrototypeOf(v) === Object.prototype && plain.length < 60) plain.push(v);
      } catch (e) {}
    }
    for (const o of plain) { // one level deeper, plain objects only
      try { for (const k of Object.keys(o).slice(0, 60)) { const d = Object.getOwnPropertyDescriptor(o, k); if (d && 'value' in d && isW(d.value)) return d.value; } } catch (e) {}
    }
    return null;
  }
  function scanFrames(win, depth) {
    let w = null;
    for (const f of win.document.querySelectorAll('iframe')) {
      frames.total++;
      try {
        const cw = f.contentWindow; void cw.document; frames.open++;
        w = scan(cw); if (w) { how = 'chart frame'; return w; }
        if (depth < 2) { w = scanFrames(cw, depth + 1); if (w) return w; }
      } catch (e) {}
    }
    return null;
  }
  function find() {
    if (captured) return captured;
    frames = { total: 0, open: 0 };
    let w = scan(window); if (w) { how = 'page'; return w; }
    return scanFrames(window, 0);
  }

  // Work out how chart values relate to market cap: underlying = marketCap * k.
  // k = 1 in MC mode; = 1/supply in Price mode; also copes with SOL mode. Learned from the chart's latest candle vs the live market cap.
  let calib = { at: 0, k: null, via: '' };
  async function calibrate(ch, cur) {
    const now = Date.now();
    if (calib.k && now - calib.at < 3000) return calib;
    let k = null, via = '';
    if (cur.mc > 0) {
      try {
        const t = Math.floor(now / 1000), d = await ch.exportData({ from: t - 1200, to: t + 60, includeTime: false });
        const rows = d && d.data;
        if (rows && rows.length) {
          let ci = d.schema ? d.schema.findIndex(s => /close/i.test(String(s.plotTitle || s.title || ''))) : -1; if (ci < 0) ci = 3;
          const last = rows[rows.length - 1][ci];
          if (last > 0) { k = last / cur.mc; via = 'candle'; }
        }
      } catch (e) {}
      if (!k) {
        try {
          const r = ch.getPanes()[0].getMainSourcePriceScale().getVisiblePriceRange(), mid = (r.from + r.to) / 2;
          if (mid / cur.mc > 0.25 && mid / cur.mc < 4) { k = 1; via = 'range'; }
          else if (cur.px > 0 && mid / cur.px > 0.25 && mid / cur.px < 4) { k = cur.px / cur.mc; via = 'range'; }
        } catch (e) {}
      }
    }
    if (!k) return null;
    if (k > 0.8 && k < 1.25) k = 1; // MC mode: no scaling noise
    if (calib.k && Math.abs(k / calib.k - 1) < 0.02) k = calib.k; // keep steady unless the chart really changed
    calib = { at: now, k, via };
    return calib;
  }
  const fmt = v => (v >= 1e6 ? (v / 1e6).toFixed(2) + 'M' : v >= 1e3 ? (v / 1e3).toFixed(2) + 'K' : v.toFixed(2));

  function drop(id) {
    const o = lines[id]; if (!o) return; delete lines[id];
    try { if (o.kind === 'pl') o.h.remove(); else if (o.id) o.ch.removeEntity(o.id, { disableUndo: true }); } catch (e) {}
  }
  const clearAll = () => Object.keys(lines).forEach(drop);

  // One dotted horizontal line with a text label. Shapes are styled reliably (unlike the default position-line tag).
  function upsert(ch, id, price, text, color) {
    let o = lines[id];
    const style = { linestyle: 1, linecolor: color, linewidth: 1, showLabel: true, textcolor: color, fontsize: 12, bold: true, horzLabelsAlign: 'right', vertLabelsAlign: 'top', text };
    if (typeof ch.createMultipointShape !== 'function') { // very old library: fall back to a position line
      if (!o) { try { o = lines[id] = { kind: 'pl', h: ch.createPositionLine({ disableUndo: true }) }; } catch (e) { return; } }
      const h = o.h, t = (fn, ...a) => { try { h[fn](...a); } catch (e) {} };
      t('setPrice', price); t('setText', text); t('setQuantity', ''); t('setLineStyle', 1); t('setLineColor', color); t('setBodyBorderColor', color); t('setBodyTextColor', color); t('setBodyBackgroundColor', '#0b0f14');
      return;
    }
    const now = Date.now();
    if (!o) o = lines[id] = { kind: 'shape', ch, id: null, price: 0, text: '', pending: false, at: 0 };
    if (o.pending) return;
    const time = Math.floor(now / 1000);
    if (o.id) {
      if (o.price === price && o.text === text) return;
      try {
        const sh = ch.getShapeById(o.id);
        sh.setPoints([{ time, price }]); try { sh.setProperties({ text, linecolor: color, textcolor: color }); } catch (e) {}
        o.price = price; o.text = text; return;
      } catch (e) { const old = o.id; o.id = null; try { ch.removeEntity(old, { disableUndo: true }); } catch (e2) {} }
    }
    if (now - o.at < 800) return;
    o.at = now; o.pending = true;
    try {
      const made = ch.createMultipointShape([{ time, price }], { shape: 'horizontal_line', lock: true, disableSelection: true, disableSave: true, disableUndo: true, text, overrides: style });
      Promise.resolve(made).then(nid => { o.pending = false; if (lines[id] === o) { o.id = nid; o.price = price; o.text = text; } else { try { ch.removeEntity(nid, { disableUndo: true }); } catch (e) {} } }).catch(() => { o.pending = false; });
    } catch (e) { o.pending = false; }
  }

  async function handle(cmd) {
    if (busy) return; busy = true;
    try {
      if (!cmd.lines || !cmd.lines.length) { clearAll(); return; }
      if (!widget) {
        if (Date.now() - findAt < 2000) return;
        findAt = Date.now(); widget = find();
        if (!widget) return say('Chart not reachable (frames: ' + frames.open + '/' + frames.total + ' readable) — this site hides its chart from extensions');
      }
      let ch; try { ch = widget.activeChart(); } catch (e) { widget = null; return say('Chart is still loading…'); }
      const cal = await calibrate(ch, cmd.cur || {});
      if (!cal) { clearAll(); return say('Could not read the chart scale yet — try again in a few seconds'); }
      const keep = {};
      for (const L of cmd.lines) {
        const mc = +L.mc; if (!(mc > 0) || !isFinite(mc)) continue;
        keep[L.id] = 1; upsert(ch, String(L.id), mc * cal.k, String(L.text || '').slice(0, 70), /^#[0-9a-f]{6}$/i.test(L.color) ? L.color : '#22c55e');
      }
      Object.keys(lines).forEach(k => { if (!keep[k]) drop(k); });
      const first = cmd.lines[0];
      say('Line drawn at MC $' + fmt(+first.mc || 0) + ' (' + (cal.k === 1 ? 'MC mode' : 'scaled') + ', via ' + how + '/' + cal.via + ')');
    } catch (e) { say('Chart line error: ' + String(e && e.message || e).slice(0, 60)); }
    finally { busy = false; }
  }

  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__ptl !== 1) return;
    lastCmdAt = Date.now(); handle(e.data);
  });
  setInterval(() => { if (Object.keys(lines).length && Date.now() - lastCmdAt > 3000) clearAll(); }, 1000);
})();

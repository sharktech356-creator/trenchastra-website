/* TrenchAstra — page-side listener.
 * Passively mirrors JSON the page ALREADY receives (fetch / XHR / WebSocket / EventSource)
 * to the extension's content script via window.postMessage. It never modifies
 * requests or responses, never sends anything over the network, and never touches wallets. */
(() => {
  if (window.__ptHooked) return;
  window.__ptHooked = true;
  const MAX = 1500000; // ignore very large payloads
  const post = (url, data) => { try { window.postMessage({ __pt: 1, url: String(url || ''), data }, '*'); } catch (e) {} };

  // Accepts plain JSON, socket.io / engine.io style prefixes ("42[...]"), and newline-delimited JSON.
  const tryJSON = (txt, url) => {
    if (typeof txt !== 'string' || txt.length < 2 || txt.length > MAX) return;
    let i = 0;
    const lim = Math.min(txt.length, 12);
    while (i < lim) { const c = txt.charCodeAt(i); if (c === 123 || c === 91) break; i++; }
    if (i >= lim) return;
    const body = i ? txt.slice(i) : txt;
    try { post(url, JSON.parse(body)); return; } catch (e) {}
    if (body.indexOf('\n') > 0) {
      for (const line of body.split('\n')) {
        const l = line.trim();
        if (l.length > 1 && (l[0] === '{' || l[0] === '[')) { try { post(url, JSON.parse(l)); } catch (e) {} }
      }
    }
  };

  const dec = new TextDecoder();
  const fromData = (d, url) => {
    try {
      if (typeof d === 'string') tryJSON(d, url);
      else if (d instanceof ArrayBuffer) { if (d.byteLength < MAX) tryJSON(dec.decode(d), url); }
      else if (ArrayBuffer.isView(d)) { if (d.byteLength < MAX) tryJSON(dec.decode(d), url); }
      else if (typeof Blob !== 'undefined' && d instanceof Blob && d.size < MAX) d.text().then(t => tryJSON(t, url)).catch(() => {});
    } catch (e) {}
  };

  // fetch: the page gets its original promise back untouched (no added latency); we read a clone on the side.
  const _fetch = window.fetch;
  window.fetch = function (...args) {
    const p = _fetch.apply(this, args);
    p.then(res => {
      try {
        const ct = (res.headers.get('content-type') || '').toLowerCase();
        if (ct && !/json|text\/plain|octet/.test(ct)) return;
        const len = +res.headers.get('content-length');
        if (len && len > MAX) return;
        const a0 = args[0];
        const url = (a0 && a0.url) || (typeof a0 === 'string' ? a0 : a0 ? String(a0) : '') || res.url;
        res.clone().text().then(t => tryJSON(t, url)).catch(() => {});
      } catch (e) {}
    }).catch(() => {});
    return p;
  };

  const _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (m, url, ...rest) { this.__ptUrl = url; return _open.call(this, m, url, ...rest); };
  const _send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...a) {
    this.addEventListener('load', () => {
      try {
        const rt = this.responseType;
        if (rt === '' || rt === 'text') tryJSON(this.responseText, this.__ptUrl);
        else if (rt === 'json' && this.response) post(this.__ptUrl, this.response);
        else if (rt === 'arraybuffer' || rt === 'blob') fromData(this.response, this.__ptUrl);
      } catch (e) {}
    });
    return _send.apply(this, a);
  };

  const OWS = window.WebSocket;
  window.WebSocket = new Proxy(OWS, {
    construct(target, args) {
      const ws = new target(...args);
      ws.addEventListener('message', ev => fromData(ev.data, ws.url));
      return ws;
    }
  });

  if (window.EventSource) {
    const OES = window.EventSource;
    window.EventSource = new Proxy(OES, {
      construct(target, args) {
        const es = new target(...args);
        es.addEventListener('message', ev => fromData(ev.data, es.url));
        return es;
      }
    });
  }
})();

# TrenchAstra — Privacy Policy

TrenchAstra is a simulation tool. It does not trade real assets.

**What it reads:** price, market-cap, volume and liquidity data that the supported trading website's page already loads in your browser (to display it next to your simulated trades). If you turn on Fast mode, it also reads the one price / market-cap number you point it at on the page; the location of that element is stored on your device.

**What it stores:** your demo balance, simulated positions, trade history and panel settings, saved locally with `chrome.storage.local` on your device.

**Chart line (optional, off by default):** if you enable it, the extension draws one dotted line on the page's own chart using the chart's built-in drawing tools. It does not read or send anything.

**What it never does:** connect to or request access to wallets, read private keys or seed phrases, sign or send transactions, read cookies or login data, make its own network requests, collect analytics, or transmit any data to the developer or any third party.

**Permissions:** only `storage` (to save your demo data) and page access on the supported sites listed in the extension.

**Deleting data:** use "Reset demo account" in Settings, or remove the extension.

TrenchAstra is not affiliated with any trading terminal. Simulated results do not predict real trading results (real fills, latency, MEV and liquidity differ). Not financial advice.

**Support (optional):** Settings → About shows a Solana address you can copy if you want to support development. The extension never contacts that address, tracks nothing, and asks nothing else of you.

**Share on X (optional):** when you press Share on X, the card image is passed through local browser storage to a small helper that runs only on x.com's post-draft page (/intent/post) and attaches it to your draft. You press Post yourself. Nothing is sent anywhere by the extension.

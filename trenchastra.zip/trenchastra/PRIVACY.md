# TrenchAstra — Privacy Policy

TrenchAstra is a simulation tool. It does not trade real assets.

**What it reads:** price, market-cap, volume and liquidity data that the supported trading website's page already loads in your browser (to display it next to your simulated trades). If you turn on Fast mode, it also reads the one price / market-cap number you point it at on the page; the location of that element is stored on your device.

**Prices for coins you are not looking at (DexScreener):** coins you hold that are not open on the page you are viewing are priced through DexScreener's free public API (`api.dexscreener.com`). The only thing sent is the token contract addresses of those open positions, with no account, wallet, balance or personal data. When you open a coin's page again, the terminal's own data is used again for it.

**What it stores:** your demo balance, simulated positions, trade history and panel settings, saved locally with `chrome.storage.local` on your device.

**Chart line (optional, off by default):** if you enable it, the extension draws one dotted line on the page's own chart using the chart's built-in drawing tools. It does not read or send anything.

**What it never does:** connect to or request access to wallets, read private keys or seed phrases, sign or send transactions, read cookies or login data, make network requests other than the DexScreener price lookup described above, collect analytics, or transmit any data to the developer or any third party.

**Permissions:** `storage` (to save your demo data), `sidePanel` (to show the side panel), page access on the supported terminal sites and the X post page, and access to `api.dexscreener.com` (for the price lookup above).

**Deleting data:** use "Reset demo account" in Settings, or remove the extension.

TrenchAstra is not affiliated with any trading terminal. Simulated results do not predict real trading results (real fills, latency, MEV and liquidity differ). Not financial advice.

**Support (optional):** Settings → About shows a Solana address you can copy if you want to support development. The extension never contacts that address, tracks nothing, and asks nothing else of you.

**Share on X (optional):** when you press Share on X, the card image is passed through local browser storage to a small helper that runs only on x.com's post-draft page (/intent/post) and attaches it to your draft. You press Post yourself. Nothing is sent anywhere by the extension.

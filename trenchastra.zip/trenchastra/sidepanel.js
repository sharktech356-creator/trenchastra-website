/* TrenchAstra — side panel. Shows your simulated account next to any page and sends buy/sell/TP/SL
 * actions to the terminal tab you are looking at. All data stays in your browser. */
(() => {
  const E = window.PTEngine, KEY = 'papertrencher', HIDE = 'pt_hidden';
  let lineMsg = '', S = null, cur = null, tabId = null, tab = 'trade', lastFull = 0, posSig = null, histSig = null, tmr = 0, toastT = 0, hidden = false;
  const $ = id => document.getElementById(id);

  /* ---------- formatting (same rules as the page panel) ---------- */
  const fin = x => x != null && isFinite(x);
  const UNITS = [[1e12, 'T'], [1e9, 'B'], [1e6, 'M'], [1e3, 'K']];
  function money(x, sign) {
    if (!fin(x)) return '—';
    const a = Math.abs(x), s = x < 0 ? '-' : (sign && x > 0 ? '+' : '');
    for (let i = 0; i < UNITS.length; i++) {
      if (a >= UNITS[i][0]) {
        let n = a / UNITS[i][0], u = UNITS[i][1];
        if (+n.toFixed(2) >= 1000 && i > 0) { n = a / UNITS[i - 1][0]; u = UNITS[i - 1][1]; }
        return s + '$' + n.toFixed(2).replace(/\.?0+$/, '') + u;
      }
    }
    return s + '$' + a.toFixed(2);
  }
  const SUBS = '₀₁₂₃₄₅₆₇₈₉';
  function px(p) {
    if (!fin(p) || p <= 0) return '—';
    if (p >= 1) return '$' + p.toFixed(p >= 1000 ? 2 : 4);
    const m = p.toExponential(2).split('e'), z = -Number(m[1]) - 1;
    if (z >= 3) return '$0.0' + String(z).split('').map(d => SUBS[+d]).join('') + m[0].replace('.', '');
    return '$' + p.toFixed(z + 3);
  }
  const pct = x => (fin(x) ? (x > 0 ? '+' : '') + x.toFixed(2) + '%' : '—');
  const cls = x => (x > 0 ? 'up' : x < 0 ? 'dn' : '');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function dur(ms) {
    if (!fin(ms) || ms < 0) return '—';
    const s = Math.round(ms / 1000);
    if (s < 60) return s + 's';
    const m = Math.floor(s / 60); if (m < 60) return m + 'm ' + (s % 60) + 's';
    const h = Math.floor(m / 60); if (h < 48) return h + 'h ' + (m % 60) + 'm';
    return Math.floor(h / 24) + 'd ' + (h % 24) + 'h';
  }
  function merge(raw) {
    const d = E.DEF(), s = Object.assign(d, raw || {});
    s.set = Object.assign(E.DEF().set, (raw && raw.set) || {});
    s.ui = Object.assign(E.DEF().ui, (raw && raw.ui) || {});
    if (!Array.isArray(s.closed)) s.closed = [];
    return s;
  }
  function toast(m, bad) {
    const t = $('toast'); t.textContent = m; t.className = 'toast show' + (bad ? ' bad' : '');
    clearTimeout(toastT); toastT = setTimeout(() => (t.className = 'toast'), 2200);
  }

  /* ---------- talking to the terminal tab ---------- */
  function act(type, payload, cb) {
    if (tabId == null) { toast('Open a token page on a supported terminal first', true); return; }
    chrome.tabs.sendMessage(tabId, Object.assign({ __pt: 'act', type }, payload || {}), r => {
      if (chrome.runtime.lastError || !r) { toast('Could not reach the terminal tab — reload it once', true); return; }
      if (r.ok === false && r.msg) toast(r.msg, true);
      if (cb) cb(r);
    });
  }
  function pollTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      const t = tabs && tabs[0]; if (!t) return;
      chrome.tabs.sendMessage(t.id, { __pt: 'act', type: 'state' }, r => {
        if (chrome.runtime.lastError || !r || !r.ok) { if (tabId !== null || cur) { tabId = null; cur = null; schedule(); } return; }
        const k = r.cur ? r.cur.key : null;
        if (tabId !== t.id || (cur && cur.key) !== k) { tabId = t.id; cur = r.cur; buildQuick(); schedule(); } else tabId = t.id;
      });
    });
  }

  /* ---------- rendering ---------- */
  function schedule() { if (!tmr) tmr = setTimeout(() => { tmr = 0; render(); }, 90); }
  function render() {
    if (!S) return;
    const sm = E.summary(S), st = E.stats(S);
    $('tiles').innerHTML = `<div class="tile"><small>EQUITY</small><b>${money(sm.equity)}</b></div><div class="tile"><small>TOTAL PNL</small><b class="${cls(sm.total)}">${money(sm.total, true)}</b></div><div class="tile"><small>CASH</small><b>${money(S.balance)}</b></div><div class="tile"><small>WIN RATE</small><b class="${st.winRate == null ? '' : st.winRate >= 50 ? 'up' : 'dn'}">${st.winRate == null ? '—' : st.winRate.toFixed(0) + '%'}</b></div>`;
    document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.t === tab));
    ['trade', 'stats', 'hist'].forEach(n => ($('v-' + n).style.display = n === tab ? '' : 'none'));
    { const lb = $('lnt'); lb.textContent = '📈 Avg line: ' + (S.set.line ? 'ON' : 'OFF'); lb.classList.toggle('on', !!S.set.line); lb.disabled = tabId == null; $('lns').textContent = S.set.line ? (lineMsg || '') : ''; }
    if (tab === 'trade') renderTrade(); else if (tab === 'stats') renderStats(); else renderHist();
  }
  function buildQuick() {
    if (!S) return;
    const ok = !!cur, hasPos = !!(cur && S.positions[cur.key]);
    $('bb').innerHTML = S.set.buys.map(v => `<button class="b buy" data-usd="${+v}" ${ok ? '' : 'disabled'}>$${+v}</button>`).join('');
    $('sb').innerHTML = S.set.sells.map(v => `<button class="b sel" data-pct="${+v}" ${hasPos ? '' : 'disabled'}>${+v}%</button>`).join('');
    $('fee').textContent = 'fee ' + S.set.fee + '% · slip ' + S.set.slip + '%';
    $('cub').disabled = !ok;
  }
  let quickSig = '';
  function renderTrade() {
    const t = cur && S.tokens[cur.key], pos = cur && S.positions[cur.key];
    const qs = JSON.stringify([S.set.buys, S.set.sells, !!cur, !!pos, S.set.fee, S.set.slip]);
    if (qs !== quickSig) { quickSig = qs; buildQuick(); }
    if (!cur) $('tok').innerHTML = '<div class="card empty">Open a token page on GMGN, Axiom, Padre, Photon or BullX.<br><span class="sub">The side panel follows the tab you are on.</span></div>';
    else if (!t) $('tok').innerHTML = `<div class="card"><div class="r1"><span class="sy">${esc(E.short(cur.addr))}</span><span class="old">Waiting for data</span></div></div>`;
    else {
      const age = (Date.now() - t.ts) / 1000;
      let me = ''; if (pos) { const a = E.posPnl(S, pos); me = `<div style="grid-column:1/3"><small>Your position (total PnL)</small><b class="${cls(a.total)}">${money(a.val)} · ${money(a.total, true)} · ${pct(a.pct)}</b></div>`; }
      $('tok').innerHTML = `<div class="card"><div class="r1"><div><div class="sy">${esc(t.symbol || E.short(cur.addr))}</div><div class="sub">${esc(t.name || E.short(cur.addr))}</div></div>${age < 15 ? '<span class="live">LIVE</span>' : `<span class="old">${Math.round(age)}s old</span>`}</div><div class="g"><div><small>Price</small><b>${t.price ? px(t.price) : '<span class="mu">n/a</span>'}</b></div><div><small>Market cap</small><b>${money(t.mcap)}</b></div><div><small>Volume</small><b>${money(t.vol)}</b></div><div><small>Liquidity</small><b>${money(t.liq)}</b></div>${me}</div></div>`;
    }
    renderPositions();
  }
  function renderPositions() {
    const ps = Object.values(S.positions), sig = ps.map(p => p.key).join('|');
    const box = $('pos');
    if (sig !== posSig) {
      posSig = sig;
      box.innerHTML = ps.length ? ps.map(p => `<div class="card p" data-pk="${esc(p.key)}"><div class="t"><span>${esc(p.sym)}</span><span data-f="pnl"></span></div>
<div class="s"><span data-f="vc"></span><span data-f="nw"></span></div><div class="s"><span data-f="bt"></span><span data-f="rl"></span></div>
<div class="tpr"><span class="up">TP</span><input type="number" min="0" step="any" placeholder="off" data-pf="tp" data-pkey="${esc(p.key)}"><span>%</span><span class="dn">SL</span><input type="number" min="0" step="any" placeholder="off" data-pf="sl" data-pkey="${esc(p.key)}"><span>%</span><span>TP sells</span><input type="number" min="1" max="100" step="any" data-pf="tps" data-pkey="${esc(p.key)}"><span>%</span></div>
<div class="s" style="margin-bottom:8px"><span data-f="tpst"></span></div>
<div class="row" style="margin:0"><button class="b sel sm" data-sell="50" data-key="${esc(p.key)}">Sell 50%</button><button class="b gh sm" data-sell="100" data-key="${esc(p.key)}">Close</button><button class="b gh sm" data-card="pos" data-key="${esc(p.key)}">PnL card</button></div></div>`).join('') : '<div class="card empty">No open positions yet.<br><span class="sub">Tap a quick-buy amount to open one.</span></div>';
    }
    if (!ps.length) return;
    const els = {}; box.querySelectorAll('.p').forEach(el => (els[el.dataset.pk] = el));
    for (const p of ps) {
      const el = els[p.key]; if (!el) continue;
      const a = E.posPnl(S, p), t2 = S.tokens[p.key];
      const set = (f, txt, c) => { const n = el.querySelector('[data-f="' + f + '"]'); if (!n) return; if (n.textContent !== txt) n.textContent = txt; if (c != null && n.dataset.c !== c) { n.className = c; n.dataset.c = c; } };
      set('pnl', money(a.total, true) + ' · ' + pct(a.pct), cls(a.total));
      set('vc', 'Value ' + money(a.val) + ' · Cost ' + money(p.cost));
      set('nw', t2 && t2.mcap ? 'Now MC ' + money(t2.mcap) : '');
      const bmc = p.mcU ? p.mcV / p.mcU : (p.b === 'm' && p.enQ ? p.enV / p.enQ : null);
      set('bt', bmc ? 'Bought at MC ' + money(bmc) : '');
      set('rl', a.rl ? 'Sold so far ' + money(a.rl, true) : '');
      const lv = m => { const x = E.levelMc(p, t2, m); return x > 0 ? ' @ MC ' + money(x) : ''; }, parts = [];
      if (p.tp > 0) parts.push(p.tpDone ? 'TP done' : 'TP +' + p.tp + '%' + lv(p.tp));
      if (p.sl > 0) parts.push('SL -' + p.sl + '%' + lv(-p.sl));
      set('tpst', parts.join('  ·  '));
      const val = { tp: p.tp || '', sl: p.sl || '', tps: p.tpSell || 100 };
      el.querySelectorAll('input[data-pf]').forEach(i => { if (document.activeElement !== i && String(i.value) !== String(val[i.dataset.pf])) i.value = val[i.dataset.pf]; });
    }
  }
  function renderStats() {
    const s = E.stats(S), box = $('v-stats');
    if (!s.n) { box.innerHTML = '<div class="card empty">No closed trades yet.<br><span class="sub">A trade counts once you fully close a position.</span></div>'; return; }
    const T = (l, v, c = '') => `<div class="tile"><small>${l}</small><b class="${c}">${v}</b></div>`;
    box.innerHTML = `<div class="card"><div class="r1"><div class="sy ${s.winRate >= 50 ? 'up' : 'dn'}" style="font-size:26px">${s.winRate.toFixed(1)}%</div><div class="sub" style="text-align:right">Win rate<br>${s.wins}W / ${s.losses}L · ${s.n} trades</div></div></div>
<div class="sg">${T('REALIZED PNL', money(S.realized, true), cls(S.realized))}${T('PROFIT FACTOR', s.pf == null ? '—' : s.pf === Infinity ? '∞' : s.pf.toFixed(2), s.pf >= 1 ? 'up' : 'dn')}${T('AVG WIN', money(s.avgWin, true), 'up')}${T('AVG LOSS', money(s.avgLoss), 'dn')}${T('BEST TRADE', money(s.best, true), cls(s.best))}${T('WORST TRADE', money(s.worst, true), cls(s.worst))}${T('EXPECTANCY', money(s.expectancy, true), cls(s.expectancy))}${T('AVG HOLD', dur(s.avgHold))}</div>`;
  }
  function renderHist() {
    const sig = S.history.length + ':' + S.closed.length + ':' + (S.history[0] ? S.history[0].ts : 0);
    if (sig === histSig) return; histSig = sig;
    const n = S.closed.length, cl = S.closed.slice(-30).map((c, j, arr) => ({ c, i: n - arr.length + j })).reverse();
    const closed = cl.length ? '<div class="sec"><span>Closed trades</span></div><div class="card">' + cl.map(({ c, i }) => `<div class="h"><span><b>${esc(c.sym)}</b><div class="sub">${new Date(c.ts).toLocaleString()}</div></span><span style="text-align:right"><b class="${cls(c.pnl)}">${money(c.pnl, true)} · ${pct(c.pct)}</b><div><button class="ghost" data-card="closed" data-i="${i}">PnL card</button></div></span></div>`).join('') + '</div>' : '';
    const all = S.history.length ? '<div class="sec"><span>All trades</span></div><div class="card">' + S.history.slice(0, 60).map(h => `<div class="h"><span><b class="${h.side === 'BUY' ? 'up' : 'dn'}">${h.side}</b>${h.tag ? ' <b class="' + (h.tag === 'TP' ? 'up' : 'dn') + '">' + h.tag + '</b>' : ''} ${esc(h.sym)}<div class="sub">${new Date(h.ts).toLocaleString()}</div></span><span style="text-align:right">${money(h.usd)}${h.mc ? `<div class="sub">@ MC ${money(h.mc)}</div>` : ''}${h.pnl != null ? `<div class="${cls(h.pnl)}" style="font-weight:700">${money(h.pnl, true)}</div>` : ''}</span></div>`).join('') + '</div>' : '<div class="card empty">No trades yet.</div>';
    $('v-hist').innerHTML = closed + all;
  }

  /* ---------- events ---------- */
  document.addEventListener('click', e => {
    const el = e.target.closest('button'); if (!el) return;
    if (el.dataset.t) { tab = el.dataset.t; histSig = null; render(); return; }
    if (el.id === 'lnt') { act('lntoggle', {}, r => r.ok && toast('Avg line ' + (r.on ? 'on' : 'off'))); return; }
    if (el.dataset.usd) { act('buy', { usd: +el.dataset.usd }, r => r.ok && toast('Bought ' + money(+el.dataset.usd))); return; }
    if (el.id === 'cub') { const v = +$('cu').value; if (!(v > 0)) return toast('Enter an amount', true); act('buy', { usd: v }, r => r.ok && toast('Bought ' + money(v))); return; }
    if (el.dataset.pct) { if (cur) act('sell', { key: cur.key, pct: +el.dataset.pct }, r => r.ok && toast('Sold ' + el.dataset.pct + '%')); return; }
    if (el.dataset.sell) { act('sell', { key: el.dataset.key, pct: +el.dataset.sell }, r => r.ok && toast('Sold ' + el.dataset.sell + '%')); return; }
    if (el.dataset.card) { act('card', { src: el.dataset.card, k: el.dataset.card === 'pos' ? el.dataset.key : el.dataset.i }, () => toast('PnL card opened on the page')); }
  });
  document.addEventListener('change', e => {
    const el = e.target;
    if (el.dataset && el.dataset.pf) act('tpsl', { key: el.dataset.pkey, f: el.dataset.pf, v: +el.value });
  });

  /* ---------- data: storage + live pushes from the terminal tabs ---------- */
  function load() {
    chrome.storage.local.get([KEY], r => { S = merge(r[KEY]); quickSig = ''; render(); });
  }
  chrome.storage.onChanged.addListener(ch => {
    if (ch[KEY] && S && Date.now() - lastFull > 1500) { S = merge(ch[KEY].newValue); schedule(); }
  });
  chrome.runtime.onMessage.addListener((m, sender, respond) => {
    if (m && m.__pt === 'event' && m.text) { toast(m.text, !!m.bad); return; }
    if (!m || m.__pt !== 'live' || !S) return;
    try { respond({ ok: 1 }); } catch (e) {}
    if (m.tokens) Object.assign(S.tokens, m.tokens);
    if (typeof m.line === 'string') lineMsg = m.line;
    if (m.S) { lastFull = Date.now(); Object.assign(S, m.S); S.set = Object.assign(E.DEF().set, m.S.set || {}); }
    schedule();
  });
  chrome.tabs.onActivated.addListener(() => pollTab());
  chrome.tabs.onUpdated.addListener((id, info) => { if (info.status === 'complete') pollTab(); });
  // Tell the page panels we are open (they hide while this beats) and that we closed (they come back at once).
  const beat = () => { try { chrome.storage.local.set({ pt_side: Date.now() }); } catch (e) {} };
  beat(); setInterval(beat, 2000);
  const bye = () => { try { chrome.storage.local.set({ pt_side: 0 }); } catch (e) {} };
  window.addEventListener('pagehide', bye); window.addEventListener('beforeunload', bye);
  load(); pollTab(); setInterval(pollTab, 1500); setInterval(() => { if (S) schedule(); }, 1000);
})();

/* TrenchAstra engine: pure logic (no DOM, no network). */
(function (g) {
  'use strict';
  const DEF = () => ({
    v: 2, start: 10000, balance: 10000, realized: 0,
    positions: {}, history: [], closed: [], tokens: {},
    set: { ver: 2, fee: 0.5, slip: 0.5, buys: [100, 250, 500, 1000], sells: [25, 50, 100], line: false, snd: true, sndBuy: true, sndVol: 60, tp: null, sl: null, tpSell: 100 },
    ui: { min: false, x: null, y: null, z: 1, w: 340, h: null }
  });

  const norm = a => (typeof a === 'string' ? (/^0x/i.test(a) ? a.toLowerCase() : a) : '');
  const ADDR_RE = /0x[a-fA-F0-9]{40}|[1-9A-HJ-NP-Za-km-z]{32,44}/g;
  const dec = s => { try { return decodeURIComponent(s || ''); } catch (e) { return s || ''; } };
  const last = s => { const m = (s || '').match(ADDR_RE); return m ? m[m.length - 1] : null; };

  // Finds the token/pair address in a terminal URL (path first, then query string).
  function parseLocation(pathname, search, host) {
    const a = last(dec(pathname)) || last(dec(search));
    if (!a) return null;
    const addr = norm(a);
    let chain = /^0x/.test(addr) ? 'evm' : 'sol';
    const seg = ((pathname || '').split('/')[1] || '').toLowerCase();
    if (/gmgn/.test(host || '') && /^[a-z0-9]{2,8}$/.test(seg)) chain = seg;
    return { chain, addr, key: chain + ':' + addr };
  }

  const ADDR_KEYS = ['address', 'token_address', 'tokenAddress', 'ca', 'mint', 'base_address', 'baseAddress', 'contract', 'token',
    'pair_address', 'pairAddress', 'pair', 'lp', 'pool', 'pool_address', 'poolAddress'];
  const K = {
    price: ['price_usd', 'priceUsd', 'priceUSD', 'usd_price', 'price', 'last_price', 'current_price'],
    mcap: ['market_cap_usd', 'marketCapUsd', 'market_cap', 'marketcap', 'marketCap', 'usd_market_cap', 'mc', 'fdv'],
    vol: ['volume_24h', 'volume24h', 'volume_usd', 'volume', 'volume_1h', 'h24_volume'],
    liq: ['liquidity_usd', 'liquidityUsd', 'liquidity', 'pool_liquidity', 'initial_liquidity'],
    hold: ['holder_count', 'holders', 'holderCount']
  };
  const pickNum = (o, ks) => {
    for (const k of ks) {
      const v = o[k];
      if (v == null || v === '' || typeof v === 'object') continue;
      const x = Number(v);
      if (isFinite(x) && x > 0) return { k, v: x };
    }
    return null;
  };
  const pickStr = (o, ks) => { for (const k of ks) if (typeof o[k] === 'string' && o[k] && o[k].length < 40) return o[k]; return null; };

  const matchesAddr = (o, addr) => ADDR_KEYS.some(k => typeof o[k] === 'string' && norm(o[k]) === addr);
  const hasPrice = o => !!(pickNum(o, K.price) || pickNum(o, K.mcap));

  // Applies one data object to the token cache. Returns true if price or mcap changed.
  function applyTick(S, cur, o, isWS, now) {
    const p = pickNum(o, K.price), m = pickNum(o, K.mcap);
    if (!p && !m) return false;
    let t = S.tokens[cur.key];
    if (t && !isWS && t.wsTs && now - t.wsTs < 1500) return false; // live stream beats REST snapshots
    if (!t) t = S.tokens[cur.key] = {};
    const scr = f => t[f === 'price' ? 'pk' : 'mk'] === 'screen' && t.scrTs && now - t.scrTs < 5000; // value read from the screen wins
    const anyScr = scr('price') || scr('mcap');
    const fresh = t.ts && now - t.ts < 20000;
    let changed = false;
    const take = (hit, field, kField, rejField) => {
      if (!hit || anyScr) return;
      if (t[kField] && t[kField] !== 'screen' && hit.k !== t[kField] && fresh) return; // don't mix price units from different keys
      const prev = t[field];
      const wild = prev && t.ts && now - t.ts < 60000 && (hit.v / prev > 20 || hit.v / prev < 0.05);
      if (wild && (t[rejField] = (t[rejField] || 0) + 1) < 3) return; // ignore one-off glitches
      t[field] = hit.v; t[kField] = hit.k; t[rejField] = 0; changed = true;
    };
    take(p, 'price', 'pk', 'rej');
    take(m, 'mcap', 'mk', 'mrej');
    const v = pickNum(o, K.vol); if (v) t.vol = v.v;
    const l = pickNum(o, K.liq); if (l) t.liq = l.v;
    const h = pickNum(o, K.hold); if (h) t.holders = h.v;
    const sy = pickStr(o, ['symbol', 'ticker']); if (sy) t.symbol = sy;
    const nm = pickStr(o, ['name']); if (nm) t.name = nm;
    t.chain = cur.chain; t.addr = cur.addr;
    if (changed && !anyScr && t.price > 0 && t.mcap > 0) t.sup = t.mcap / t.price; // rough supply, used only as a fallback
    if (changed) { t.ts = now; if (isWS) t.wsTs = now; }
    return changed;
  }

  // Applies a number read straight from the terminal screen ('price' | 'mcap').
  function applyScreen(S, cur, f, val, now, ctr, lockOther, supply) {
    let t = S.tokens[cur.key];
    if (!t) t = S.tokens[cur.key] = {};
    const prev = t[f];
    if (prev && t.ts && now - t.ts < 60000 && (val / prev > 20 || val / prev < 0.05)) {
      if ((ctr[f] = (ctr[f] || 0) + 1) < 3) return false; // ignore one-off glitches
    }
    ctr[f] = 0;
    const o = f === 'price' ? 'mcap' : 'price';
    if (!lockOther) { // keep the other field exact: price x supply = market cap
      if (supply > 0) t[o] = f === 'price' ? val * supply : val / supply;
      else if (prev > 0 && t[o] > 0) { const r = val / prev; if (r > 0.2 && r < 5) t[o] *= r; }
    }
    t[f] = val; t[f === 'price' ? 'pk' : 'mk'] = 'screen';
    t.ts = now; t.scrTs = now; t.chain = cur.chain; t.addr = cur.addr;
    return true;
  }

  // Parses terminal-style numbers: $12.3K, 1.2M, 4,567.89, 0.0₅123 (subscript zeros).
  const SUBD = '₀₁₂₃₄₅₆₇₈₉';
  function parseNum(str) {
    let s = String(str == null ? '' : str).replace(/[\s\u00a0$,~≈<>]/g, '');
    if (!s) return null;
    let m = s.match(new RegExp('^0\\.0([' + SUBD + ']+)(\\d+)$'));
    if (m) { const z = Number(Array.from(m[1]).map(c => SUBD.indexOf(c)).join('')); return Number('0.' + '0'.repeat(z) + m[2]); }
    m = s.match(/^(\d*\.?\d+)([KMBTkmbt])?$/);
    if (!m) return null;
    const mult = { k: 1e3, m: 1e6, b: 1e9, t: 1e12 }[(m[2] || '').toLowerCase()] || 1;
    const x = Number(m[1]) * mult;
    return isFinite(x) ? x : null;
  }

  const basisPx = (b, t) => (t ? (b === 'p' ? t.price : t.mcap) : null);
  const posValue = (S, p) => { const x = basisPx(p.b, S.tokens[p.key]); return x ? p.q * x : null; };
  // Total PnL of a position = realized (already-sold part) + unrealized (still open). Partial sells never change it.
  function posPnl(S, p) {
    const v = posValue(S, p), val = v == null ? p.cost : v;
    const un = val - p.cost, rl = p.rl || 0, inv = p.inv || p.cost || 1, total = un + rl;
    return { val, un, rl, inv, total, pct: total / inv * 100 };
  }
  // Market cap at which a position's open PnL (vs its cost) reaches `move` percent.
  function levelMc(p, t, move) {
    if (!(p && p.q > 0 && p.cost > 0)) return null;
    const x = (p.cost / p.q) * (1 + move / 100);
    if (p.b === 'm') return x;
    return t && t.mcap > 0 && t.price > 0 ? x * (t.mcap / t.price) : null;
  }
  // Auto take-profit / stop-loss. Acts only on fresh data and only when the condition holds for ~350 ms (ignores one-frame glitches).
  function tpslCheck(S, now, memo) {
    const out = [];
    for (const key of Object.keys(S.positions)) {
      const p = S.positions[key]; if (!p || !(p.tp > 0 || p.sl > 0)) continue;
      const t = S.tokens[key]; if (!t || !t.ts || now - t.ts > 10000) { delete memo[key]; continue; }
      const v = posValue(S, p); if (v == null || !(p.cost > 0)) continue;
      const u = (v / p.cost - 1) * 100;
      let kind = null;
      if (p.sl > 0 && u <= -p.sl) kind = 'SL'; else if (p.tp > 0 && !p.tpDone && u >= p.tp) kind = 'TP';
      if (!kind) { delete memo[key]; continue; }
      const m = memo[key];
      if (!m || m.kind !== kind) { memo[key] = { kind, at: now }; continue; }
      if (now - m.at < 350) continue;
      delete memo[key];
      const pc = kind === 'SL' ? 100 : Math.min(100, p.tpSell || 100), sym = p.sym;
      const r = sell(S, key, pc, now, kind);
      if (r.ok) { if (S.positions[key]) S.positions[key].tpDone = kind === 'TP' ? true : S.positions[key].tpDone; out.push({ kind, sym, u, pc, pnl: r.pnl, closed: r.closed }); }
    }
    return out;
  }
  const short = a => (a && a.length > 10 ? a.slice(0, 4) + '…' + a.slice(-4) : a || '');

  function buy(S, cur, usd, now, opts) {
    usd = Number(usd);
    if (!cur) return { ok: false, msg: 'Open a token page first' };
    const t = S.tokens[cur.key];
    if (!t || (!t.price && !t.mcap)) return { ok: false, msg: 'No live data captured yet' };
    if (!(usd > 0) || !isFinite(usd)) return { ok: false, msg: 'Invalid amount' };
    if (usd > S.balance + 1e-9) return { ok: false, msg: 'Not enough demo funds' };
    let p = S.positions[cur.key];
    const b = p ? p.b : opts && opts.basis ? opts.basis : (t.pk === 'screen' && t.price ? 'p' : t.mk === 'screen' && t.mcap ? 'm' : (t.price ? 'p' : 'm'));
    const x = basisPx(b, t);
    if (!x) return { ok: false, msg: 'Price unavailable right now' };
    const fee = usd * S.set.fee / 100;
    const ex = x * (1 + S.set.slip / 100);
    const q = (usd - fee) / ex;
    if (!p) p = S.positions[cur.key] = { key: cur.key, chain: cur.chain, addr: cur.addr, sym: t.symbol || short(cur.addr), b, q: 0, cost: 0, inv: 0, rl: 0, ts: now, enV: 0, enQ: 0, exV: 0, exQ: 0,
      tp: S.set.tp > 0 ? S.set.tp : null, sl: S.set.sl > 0 ? S.set.sl : null, tpSell: S.set.tpSell > 0 ? Math.min(100, S.set.tpSell) : 100, tpDone: false, path: [], mk: [] };
    p.enV = (p.enV || 0) + ex * q; p.enQ = (p.enQ || 0) + q;
    if (t.mcap > 0) { (p.mk = p.mk || []).push({ t: now, k: 'B', v: t.mcap }); (p.path = p.path || []).push([now, t.mcap]); }
    if (t.mcap > 0) { p.mcV = (p.mcV || 0) + t.mcap * usd; p.mcU = (p.mcU || 0) + usd; }
    p.q += q; p.cost += usd; p.inv = (p.inv || 0) + usd; S.balance -= usd;
    S.history.unshift({ ts: now, side: 'BUY', sym: p.sym, key: p.key, usd, price: ex, pnl: null, mc: t.mcap || null });
    if (S.history.length > 500) S.history.length = 500;
    return { ok: true, msg: 'Bought ' + p.sym };
  }

  function sell(S, key, pc, now, tag) {
    const p = S.positions[key];
    if (!p) return { ok: false, msg: 'No position' };
    pc = Number(pc);
    if (!(pc > 0) || pc > 100) return { ok: false, msg: 'Invalid percentage' };
    const x = basisPx(p.b, S.tokens[key]);
    if (!x) return { ok: false, msg: 'No live price — open this token' };
    const sq = p.q * pc / 100;
    const ex = x * (1 - S.set.slip / 100);
    const proceeds = sq * ex * (1 - S.set.fee / 100);
    const costPart = p.cost * pc / 100;
    const tk = S.tokens[key]; if (tk && tk.mcap > 0) { p.xmV = (p.xmV || 0) + tk.mcap * proceeds; p.xmU = (p.xmU || 0) + proceeds; }
    const pnl = proceeds - costPart;
    S.balance += proceeds; S.realized += pnl; p.rl = (p.rl || 0) + pnl;
    p.exV = (p.exV || 0) + ex * sq; p.exQ = (p.exQ || 0) + sq;
    { const tk0 = S.tokens[key]; if (tk0 && tk0.mcap > 0) { (p.mk = p.mk || []).push({ t: now, k: 'S', v: tk0.mcap }); (p.path = p.path || []).push([now, tk0.mcap]); } }
    p.q -= sq; p.cost -= costPart;
    S.history.unshift({ ts: now, side: 'SELL', sym: p.sym, key, usd: proceeds, price: ex, pnl, pct: pc, tag: tag || null });
    if (S.history.length > 500) S.history.length = 500;
    let closed = false;
    if (pc >= 99.999 || p.q <= 0) {
      const inv = p.inv || 1;
      S.closed.push({ ts: now, sym: p.sym, key, chain: p.chain, b: p.b, pnl: p.rl, pct: p.rl / inv * 100, inv, hold: now - p.ts,
        entry: p.enQ ? p.enV / p.enQ : null, exit: p.exQ ? p.exV / p.exQ : null, path: (p.path || []).slice(), mk: (p.mk || []).slice(), ts0: p.ts,
        entryMc: p.mcU ? p.mcV / p.mcU : (p.b === 'm' && p.enQ ? p.enV / p.enQ : null),
        exitMc: p.xmU ? p.xmV / p.xmU : (p.b === 'm' && p.exQ ? p.exV / p.exQ : null) });
      if (S.closed.length > 1000) S.closed.shift();
      delete S.positions[key]; closed = true;
    }
    return { ok: true, pnl, closed, msg: 'Sold ' + pc + '% ' + p.sym };
  }

  function summary(S) {
    let pv = 0;
    for (const p of Object.values(S.positions)) { const v = posValue(S, p); pv += v == null ? p.cost : v; }
    const equity = S.balance + pv;
    return { equity, posValue: pv, total: equity - S.start };
  }

  function stats(S) {
    const c = S.closed || [];
    const w = c.filter(x => x.pnl > 0), l = c.filter(x => x.pnl <= 0);
    const sum = a => a.reduce((s, x) => s + x.pnl, 0);
    const gw = sum(w), gl = Math.abs(sum(l));
    let streak = 0;
    for (let i = c.length - 1; i >= 0; i--) {
      const win = c[i].pnl > 0;
      if (i === c.length - 1) streak = win ? 1 : -1;
      else if ((streak > 0) === win) streak += win ? 1 : -1; else break;
    }
    let cum = 0; const curve = c.map(x => (cum += x.pnl));
    return {
      n: c.length, wins: w.length, losses: l.length,
      winRate: c.length ? w.length / c.length * 100 : null,
      avgWin: w.length ? gw / w.length : null, avgLoss: l.length ? -gl / l.length : null,
      best: c.length ? Math.max(...c.map(x => x.pnl)) : null, worst: c.length ? Math.min(...c.map(x => x.pnl)) : null,
      pf: gl > 0 ? gw / gl : (gw > 0 ? Infinity : null),
      avgHold: c.length ? c.reduce((s, x) => s + x.hold, 0) / c.length : null,
      expectancy: c.length ? sum(c) / c.length : null, streak, curve
    };
  }

  g.PTEngine = { DEF, norm, parseLocation, ADDR_KEYS, matchesAddr, hasPrice, applyTick, applyScreen, parseNum, buy, sell, summary, stats, posValue, posPnl, levelMc, tpslCheck, short };
  if (typeof module !== 'undefined') module.exports = g.PTEngine;
})(typeof globalThis !== 'undefined' ? globalThis : this);

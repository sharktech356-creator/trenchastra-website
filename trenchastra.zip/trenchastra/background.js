/* TrenchAstra — background (service worker): opens the side panel. Nothing else. */
chrome.runtime.onInstalled.addListener(() => {
  try { chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }); } catch (e) {}
});
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (!m || m.__pt !== 'open-side') return;
  try {
    const wid = sender.tab && sender.tab.windowId;
    chrome.sidePanel.open({ windowId: wid }).then(() => respond({ ok: true })).catch(e => respond({ ok: false, err: String(e) }));
  } catch (e) { respond({ ok: false, err: 'unsupported' }); }
  return true; // async response
});
chrome.commands.onCommand.addListener((cmd, tab) => {
  if (cmd === 'open-side-panel' && tab) { try { chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {}); } catch (e) {} }
});

// Side panel presence: the panel keeps a connection open; when it closes, the page panels come back immediately.
chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'trenchastra-side') return;
  try { chrome.storage.local.set({ pt_side: Date.now() }); } catch (e) {}
  port.onMessage.addListener(() => {}); // pings keep this worker awake while the panel is open
  port.onDisconnect.addListener(() => { try { chrome.storage.local.set({ pt_side: 0 }); } catch (e) {} });
});
try { if (chrome.sidePanel && chrome.sidePanel.onClosed) chrome.sidePanel.onClosed.addListener(() => chrome.storage.local.set({ pt_side: 0 })); } catch (e) {}

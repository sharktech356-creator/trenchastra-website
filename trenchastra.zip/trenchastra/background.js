/* TrenchAstra — background (service worker): opens the side panel. Nothing else. */
chrome.runtime.onInstalled.addListener(() => {
  try { chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }); } catch (e) {}
});
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (!m || m.__pt !== 'open-side') return;
  try {
    const wid = sender.tab && sender.tab.windowId;
    chrome.sidePanel.open({ windowId: wid }).then(() => respond({ ok: true })).catch(e => respond({ ok: false, err: String(e) }));
  } catch (e) { respond({ ok: false, err: 'unsupported' }); }
  return true; // async response
});
chrome.commands.onCommand.addListener((cmd, tab) => {
  if (cmd === 'open-side-panel' && tab) { try { chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {}); } catch (e) {} }
});

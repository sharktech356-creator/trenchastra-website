/* TrenchAstra — background (service worker): opens the side panel. Nothing else. */
chrome.runtime.onInstalled.addListener(() => {
  try { chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }); } catch (e) {}
});
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (!m || m.__pt !== 'open-side') return;
  try {
    const wid = sender.tab && sender.tab.windowId;
    chrome.sidePanel.open({ windowId: wid }).then(() => respond({ ok: true })).catch(e => respond({ ok: false, err: String(e) }));
  } catch (e) { respond({ ok: false, err: 'unsupported' }); }
  return true; // async response
});
chrome.commands.onCommand.addListener((cmd, tab) => {
  if (cmd === 'open-side-panel' && tab) { try { chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {}); } catch (e) {} }
});

// Side panel presence: the panel keeps a connection open; when it closes, the page panels come back immediately.
chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'trenchastra-side') return;
  try { chrome.storage.local.set({ pt_side: Date.now() }); } catch (e) {}
  port.onMessage.addListener(() => {}); // pings keep this worker awake while the panel is open
  port.onDisconnect.addListener(() => { try { chrome.storage.local.set({ pt_side: 0 }); } catch (e) {} });
});
try { if (chrome.sidePanel && chrome.sidePanel.onClosed) chrome.sidePanel.onClosed.addListener(() => chrome.storage.local.set({ pt_side: 0 })); } catch (e) {}

// DexScreener prices (free public API) for coins that are open in your account but not on the page you are looking at.
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (!m || m.__pt !== 'dex') return;
  const addrs = (m.addrs || []).slice(0, 30).map(a => String(a).replace(/[^A-Za-z0-9]/g, '')).filter(Boolean).join(',');
  const chain = String(m.chain || '').replace(/[^a-z0-9]/gi, '');
  if (!addrs) { respond({ ok: false, err: 'no addresses' }); return; }
  const urls = chain ? ['https://api.dexscreener.com/tokens/v1/' + chain + '/' + addrs, 'https://api.dexscreener.com/latest/dex/tokens/' + addrs]
                     : ['https://api.dexscreener.com/latest/dex/tokens/' + addrs];
  (async () => {
    for (const u of urls) {
      try {
        const r = await fetch(u, { cache: 'no-store' });
        if (!r.ok) continue;
        const j = await r.json();
        const pairs = Array.isArray(j) ? j : (j && j.pairs) || [];
        if (pairs.length || u === urls[urls.length - 1]) { respond({ ok: true, pairs }); return; }
      } catch (e) {}
    }
    respond({ ok: false, err: 'DexScreener not reachable' });
  })();
  return true; // async response
});

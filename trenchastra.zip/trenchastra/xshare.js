/* TrenchAstra — X share helper.
 * Runs ONLY on x.com / twitter.com post-draft pages (/intent/post). When you press "Share on X" on a PnL card,
 * the card image is handed over through local extension storage and attached to the draft for you.
 * Nothing is posted automatically and nothing is sent anywhere: you still press Post yourself. */
(() => {
  const KEY = 'pt_share';
  try {
    chrome.storage.local.get(KEY, r => {
      const s = r && r[KEY];
      if (!s || !s.img || Date.now() - s.at > 120000) return; // only a fresh card from the last 2 minutes
      chrome.storage.local.remove(KEY);
      let file;
      try {
        const bin = atob(String(s.img).split(',')[1] || ''), u8 = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
        file = new File([u8], 'trenchastra-pnl.png', { type: 'image/png' });
      } catch (e) { return; }
      const find = () => document.querySelector('[data-testid="tweetTextarea_0"]') || document.querySelector('div[role="textbox"][contenteditable="true"]');
      const t0 = Date.now();
      const iv = setInterval(() => {
        const ed = find();
        if (!ed) { if (Date.now() - t0 > 20000) clearInterval(iv); return; }
        clearInterval(iv);
        setTimeout(() => {
          try {
            ed.focus();
            const dt = new DataTransfer(); dt.items.add(file);
            ed.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
          } catch (e) {}
        }, 700); // let the draft finish loading its text first
      }, 250);
    });
  } catch (e) {}
})();

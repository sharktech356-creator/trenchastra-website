# TrenchAstra
Install: chrome://extensions → Developer mode → Load unpacked → select this folder. Open a token page and reload it once.
Supported: gmgn.ai, axiom.trade, padre.gg / trade.padre.gg (Terminal), photon-sol.tinyastro.io, *.bullx.io.
Alt+P toggles the panel. See PRIVACY.md.

New in 1.1: sell PnL stays constant on partial sells (position PnL = realized + open), editable quick buy/sell buttons (✎ Edit),
PnL card (PNG) for open and closed trades, faster data capture, and Fast mode (Settings → Pick Price / Pick Market Cap).

v1.4: removed the list quick-buy overlay. Added the 📈 Avg line toggle (Trade tab, next to Open positions): a dotted line on the chart at your average buy with live PnL.

v1.6.1: Settings → About with an optional support address (copy + QR).

v1.7.0: default fee/slippage 0.5%; Settings now has a Save settings button (starting balance changes keep PnL).

v1.8.0: Settings → Account balance has its own Save balance button (two-step confirm). Saving a new balance wipes all positions, history and stats.

v1.9.0: Share on X button on PnL cards (copies the card, opens a ready-to-post draft). Set SITE_URL in content.js to add your website link to the post.

v1.9.1: Share on X now attaches the card to the draft (helper runs only on x.com/intent/post) and uses a short post text.

v1.10.0: New PnL card layout with a real market-cap chart (buy/sell markers, entry line). Optional CARD_HANDLE and SITE_URL constants in content.js show your X handle and website on the card.

v1.11.0: Side panel (toolbar popup, ▤ button on the page panel, or Alt+Shift+P). TP and SL sound effects with your own audio option (Settings → Sounds). PnL card: smaller PAPER chip, no disclaimer line.

v1.11.1: PnL cards and X posts use https://trenchastra.vercel.app; no X handle shown until one exists (CARD_HANDLE in content.js).

v1.12.0: The floating panel hides automatically while the side panel is open and returns when it closes. TP/SL alerts show in the side panel too.

v1.12.1: PnL card header is clean; the PAPER label now sits in the details line under the ticker.

v1.13.0: Avg line on/off switch in the side panel. New trade-open sound (Settings -> Sounds, with its own on/off and custom file).

v1.13.1: Avg line is on by default. Closing the side panel now brings the floating panel back immediately (connection + visibility checks).

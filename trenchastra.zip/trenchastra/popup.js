const cb = document.getElementById('show');
chrome.storage.local.get('pt_hidden', r => { cb.checked = !r.pt_hidden; });
cb.addEventListener('change', () => chrome.storage.local.set({ pt_hidden: !cb.checked }));
